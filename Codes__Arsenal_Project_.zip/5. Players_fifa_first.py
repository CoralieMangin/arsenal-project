#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Origine des csv : https://www.kaggle.com/stefanoleone992/fifa-20-complete-player-dataset?select=players_20.csv

"""
Ce script permet de rassembler plusieurs fichiers csv téléchargeables avec le lien ci-dessus et de les rassembler en un seul DataFrame.
Celui-ci est ensuite nettoyé et uniformisé : 
    - gestion des valeurs manquantes;
    - uniformisation des noms des équipes;
    - etc. 
A la fin, le fichier propre contient l'ensemble des données des joueurs de football du jeu Fifa en mode carrière, pour une période allant de 2014 à 2020.
Il est finalement extrait sous le nom "players_fifa.csv".
"""


# # Création d'un premier DataFrame des joueurs à partir de données fifa

# In[2]:


# On note que ce csv ne débute qu'en 2014.
# Nous devrons compléter ces données pour les années précédentes.


# In[3]:


# Import des modules
import pandas as pd
import numpy as np

# Import des csv
df15 = pd.read_csv(r"players_15.csv")
df16 = pd.read_csv(r"players_16.csv")
df17 = pd.read_csv(r"players_17.csv")
df18 = pd.read_csv(r"players_18.csv")
df19= pd.read_csv(r"players_19.csv")
df20 = pd.read_csv(r"players_20.csv")


# ## Regroupement des DataFrames

# In[4]:


# Ajout d'une colonne pour indiquer la saison
df15['season'] = '14/15'
df16['season'] = '15/16'
df17['season'] = '16/17'
df18['season'] = '17/18'
df19['season'] = '18/19'
df20['season'] = '19/20'

# Concaténation en un seul DataFrame
df = pd.concat([df15,df16,df17,df18,df19,df20], axis=0, ignore_index=True)

# Suppression des colonnes qui ne serviront pas 
to_drop = ['joined','contract_valid_until','short_name', 'weight_kg','team_jersey_number','skill_moves','nation_position','nation_jersey_number','weak_foot','player_url',
           'loaned_from','body_type','real_face','release_clause_eur','player_tags','nationality','player_traits','mentality_composure','work_rate',
           'ls','st','rs','lw','lf','cf','rf','rw','lam','cam','ram','lm','lcm','cm','rcm','rm','lwb','ldm','cdm','rdm','rwb','lb','lcb','international_reputation',
           'cb','rcb','rb','gk_diving', 'gk_handling', 'gk_kicking', 'gk_reflexes', 'gk_speed','gk_positioning','pace', 'shooting', 'passing', 'dribbling', 'defending', 'physic']
df.drop(to_drop, axis=1, inplace=True)

# Affichage des caractéristiques et des premières lignes
print(df.info())
df.head(5)


# ## Gestion des NANs

# In[5]:


#### Définition d'une fonction pour afficher les valeurs manquantes par colonne

def valeur_manquante(df):
    """
    Cette fonction prend un DataFrame en paramètre et permet d'afficher le nombre de valeurs manquantes pour chaque colonne de celui-ci.
    """
    flag=0
    for col in df.columns:
            if df[col].isna().sum() > 0:
                flag=1
                print(f'"{col}": {df[col].isna().sum()} valeurs manquantes')
    if flag==0:
        print("Le dataset ne contient plus de valeurs manquantes.")
        
valeur_manquante(df)


# In[6]:


# Fifa 15 et Fifa 16 ont des colonnes entières de NaNs (value_eur, wage_eur). On peut les remplace par 0.
df['value_eur'] = df['value_eur'].fillna(0)
df['wage_eur'] = df['wage_eur'].fillna(0)

# Pour la colonne 'team_position', la valeur peut être remplacée par la première de celle de la colonne 'player_position' (colonne qu'on supprime ensuite)
df['team_position'] = df['team_position'].fillna(df['player_positions'])
df['team_position'] = df['team_position'].astype(str).str.split(',', expand=True)[0]
df.drop('player_positions', axis=1, inplace=True)


# ## Format des colonnes

# In[ ]:


# Les colonnes de statistiques contiennent souvent une première valeur suivie d'un '+' ou d'un '-' puis d'une seconde valeur.
# Il s'agit d'une modification minime des statistiques appliquée lors de visualisation de matchs ultérieurs.
# On ne souhaite garder que la première valeur donc on va simplement ôter tout ce qui est après le caractère '+' ou '-'.
# On définit une fonction qui va effectuer un 'split' sur deux caractères que l'on passe en arguments,
# sur une liste de colonnes passée en argument également.
# Elle conserve la première partie du 'split'et remplace la valeur initiale de chaque colonne par celle-ci

def split (liste, carac1, carac2) : # Liste de colonnes, et 2 caractères en arguments
    """
    Cette fonction prend en paramètres une liste et deux caractères (carac1 et carac2).
    Elle permet de parcourir chaque valeur de la liste et en deux étapes (une pour chaque caractère), 
    de couper la valeur sur le caractère définis et de ne garder que la première partie de l'expression (avant le caractère).
    """
    for col in liste :  # On parcourt les colonnes dans la liste
        df[col] = df[col].astype(str).apply(lambda x : x.split(str(carac1))[0]) 
        df[col] = df[col].astype(str).apply(lambda x : x.split(str(carac2))[0])

# Liste de colonne sur lesquelles on veut appliquer cette modification
column = ['attacking_crossing',
        'attacking_finishing',
        'attacking_heading_accuracy',
        'attacking_short_passing',
        'attacking_volleys',
        'skill_dribbling',
        'skill_curve',
        'skill_fk_accuracy',
        'skill_long_passing',
        'skill_ball_control',
        'movement_acceleration',
        'movement_sprint_speed',
        'movement_agility',
        'movement_reactions',
        'movement_balance',
        'power_shot_power',
        'power_jumping',
        'power_stamina',
        'power_strength', 
        'power_long_shots',
        'mentality_aggression',
        'mentality_interceptions',
        'mentality_positioning',
        'mentality_vision',
        'mentality_penalties',
        'defending_marking',
        'defending_standing_tackle',
        'defending_sliding_tackle',
        'goalkeeping_diving',
        'goalkeeping_handling',
        'goalkeeping_kicking',
        'goalkeeping_positioning',
        'goalkeeping_reflexes']

split(column, '+', '-')  # On applique la fonction sur la liste


# In[ ]:


# On renomme les colonnes pour uniformiser par rapport aux autres DataFrames
df = df.rename(columns={'sofifa_id':'player_fifa_api_id','long_name':'player_name', 'team_position':'position', 'dob':'birthday'})


# In[ ]:


# On passa la colonne 'birthday' au format datetime

df['birthday'] = pd.to_datetime(df['birthday'])


# ## Uniformisation du nom des équipes

# In[ ]:


# On renomme les équipes de l'English Premier League pour les uniformiser par rapport aux noms dans les autres DataFrames

team_to_replace = {'Tottenham' : 'Tottenham Hotspur',
                    'Leicester' : 'Leicester City',   
                    'Stoke' : 'Stoke City', 
                    'West Ham' : 'West Ham United', 
                    'Swansea' : 'Swansea City', 
                    'Hull' : 'Hull City', 
                    'Norwich' : 'Norwich City',
                    'Bournemouth' : 'AFC Bournemouth', 
                    'Brighton' : 'Brighton and Hove Albion',
                    'Huddersfield' : 'Huddersfield Town', 
                    'Cardiff' : 'Cardiff City'}

df['club'] = df['club'].replace(team_to_replace)


# In[ ]:


df.head(5)


# ## Exporter le csv

# In[ ]:


# Matchs de Premier League (coupe nationale)
df.to_csv(r'clean_csv/players_fifa.csv', index=False)

