#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import matplotlib.pyplot as plt 
import seaborn as sns
import numpy as np
get_ipython().run_line_magic('matplotlib', 'inline')


# ## Read the csv

# In[2]:


df = pd.read_csv('df_full_premierleague.csv')
df_copy1 = df
df.head()


# In[3]:


df.columns


# In[4]:


df.columns = [col.strip() for col in list(df.columns)]


# ## Separate arsenal matches onto a new dataframe

# In[5]:


df['home_team'] = df['home_team'].astype(str)
df['away_team'] = df['away_team'].astype(str)


# In[6]:


arsenal = df[(df['home_team'] == 'Arsenal') | (df['away_team'] == 'Arsenal')]


# In[7]:


arsenal = arsenal.drop(arsenal.columns[38:76], axis = 1) 


# In[8]:


# Calculate wins and losses


# In[9]:


def arsenal_results(c):
    if (c['home_team'] == 'Arsenal') & (c['goal_home_ft'] > c['goal_away_ft']):
        return 'W'
    elif (c['home_team'] == 'Arsenal') & (c['goal_home_ft'] < c['goal_away_ft']):
        return 'L'
    elif (c['home_team'] == 'Arsenal') & (c['goal_home_ft'] == c['goal_away_ft']):
        return 'D'
    elif (c['away_team'] == 'Arsenal') & (c['goal_home_ft'] > c['goal_away_ft']):
        return 'L'
    elif (c['away_team'] == 'Arsenal') & (c['goal_home_ft'] < c['goal_away_ft']):
        return 'W'
    elif (c['away_team'] == 'Arsenal') & (c['goal_home_ft'] == c['goal_away_ft']):
        return 'D'
    else:
        'N/A'


# In[10]:


arsenal['arsenal_results'] = arsenal.apply(arsenal_results, axis=1).astype(str)


# In[11]:


# Calculate goal number


# In[12]:


def arsenal_goals(c):
    if (c['home_team'] == 'Arsenal'):
        return c['goal_home_ft']
    elif (c['away_team'] == 'Arsenal'):
        return c['goal_away_ft']


# In[13]:


arsenal['arsenal_goals'] = arsenal.apply(arsenal_goals, axis = 1)


# In[14]:


# Calculate match goals 


# In[15]:


arsenal['arsenal_points'] = arsenal.apply(lambda x: 3 if x['arsenal_results'] == 'W' 
                                          else 1 if x['arsenal_results'] == 'D'
                                          else 0, axis= 1)


# In[16]:


arsenal.head()


# In[17]:


arsenal.groupby('arsenal_results')[['arsenal_results']].count()


# In[18]:


arsenal_PL_overview = arsenal.groupby('arsenal_results')[['arsenal_results']].count()


# In[19]:


arsenal.groupby(['season', 'arsenal_results'])[['arsenal_results']].count()


# In[20]:


arsenal_results_season = arsenal.groupby(['season', 'arsenal_results'])[['arsenal_results']].count()


# ## ALL DATAFRAME - Classement 

# In[21]:


### Winning team column for all matches-> deduct goals from it in another column to have classement


# In[22]:


df.head(2)


# In[23]:


def winning_team(c): 
    if c['goal_home_ft'] > c['goal_away_ft']:
        return c['home_team']
    elif c['goal_home_ft'] < c['goal_away_ft']:
        return c['away_team']


# In[24]:


df['Win'] = df.apply(winning_team, axis= 1)


# In[25]:


def losing_team(c):
    if c['goal_home_ft'] > c['goal_away_ft']:
        return c['away_team']
    elif c['goal_home_ft'] < c['goal_away_ft']:
        return c['home_team']


# In[26]:


df['Loss'] = df.apply(losing_team, axis= 1)


# In[27]:


def draw_home(c):
    if c['goal_home_ft'] == c['goal_away_ft']:
        return c['home_team']


# In[28]:


df['draw_home'] = df.apply(draw_home, axis= 1)


# In[29]:


def draw_away(c):
    if c['goal_home_ft'] == c['goal_away_ft']:
        return c['away_team']


# In[30]:


df['draw_away'] = df.apply(draw_away, axis= 1)


# In[31]:


df.head()


# In[32]:


# Wins 


# In[33]:


winner_df = df[['season','Win']]


# In[34]:


def winner(x):
    if x['Win'] == None:
        return 0
    else:
        return 1


# In[35]:


winner_df['winner'] = winner_df.apply(winner, axis = 1).astype(int)


# In[36]:


winner_df.head()


# In[37]:


winner_df = winner_df.set_index('Win')


# In[38]:


winner_df.index.rename('Team', inplace = True)


# In[40]:


winner_df = winner_df.reset_index()


# In[41]:


winner_df.isna().sum()


# In[42]:


winner_df = winner_df.set_index('Team')


# In[43]:


winner_df.head()


# In[44]:


# Losses 


# In[45]:


losers_df = df[['season','Loss']]
losers_df.head()


# In[46]:


def loser(x):
    if x['Loss'] == None:
        return 0
    else:
        return 1


# In[47]:


losers_df['loser'] = losers_df.apply(loser, axis = 1)


# In[48]:


losers_df.isna().sum()


# In[49]:


losers_df = losers_df.dropna()


# In[50]:


losers_df = losers_df.rename(columns = {'Loss': 'Team'})
losers_df.head()


# In[51]:


losers_df = losers_df.set_index('Team')


# In[52]:


losers_df.head()


# In[53]:


# Draw home


# In[54]:


home_draw_df = df[['season','draw_home']]
home_draw_df.head()


# In[55]:


def draw(x):
    if x['draw_home'] == None:
        return 0
    else:
        return 1


# In[56]:


home_draw_df['home_draw'] = home_draw_df.apply(draw, axis = True)


# In[57]:


home_draw_df.isna().sum()


# In[58]:


home_draw_df = home_draw_df.rename(columns = {'draw_home': 'Team'})


# In[59]:


home_draw_df = home_draw_df.dropna()


# In[60]:


home_draw_df = home_draw_df.set_index('Team')


# In[61]:


home_draw_df.head()


# In[62]:


# away draw 


# In[63]:


away_draw_df = df[['season','draw_away']]


# In[64]:


def draw_a(x):
    if x['draw_away'] == None:
        return 0
    else:
        return 1


# In[65]:


away_draw_df['away_draw'] = away_draw_df.apply(draw_a, axis = 1)


# In[66]:


away_draw_df.isna().sum()


# In[67]:


away_draw_df = away_draw_df.dropna()


# In[68]:


away_draw_df = away_draw_df.rename(columns = {'draw_away':'Team'})


# In[69]:


away_draw_df = away_draw_df.set_index('Team')


# In[70]:


#list dataframe you want to append
frame = [winner_df, losers_df, home_draw_df, away_draw_df]

#new dataframe to store append result
final_listing = pd.DataFrame()

for x in frame:
    final_listing = final_listing.append(x)


# In[71]:


final_listing.head()


# In[72]:


# check
xo = final_listing.reset_index()
xo
a = xo['Team'].nunique()
print(a, 'teams')


# In[73]:


final_listing.update(final_listing[['winner', 'loser', 'home_draw','away_draw']].fillna(0))


# In[74]:


final_listing[['winner','loser','home_draw', 'away_draw']] = final_listing[['winner','loser','home_draw', 'away_draw']].apply(lambda x: x.astype(int))


# In[75]:


final_listing.groupby(['Team','season']).sum().sort_values('winner', ascending = False).head()


# In[76]:


## Adding a column that calculates the final points results based on all the columns (winner, loser, draws)


# In[77]:


def points(c):
    return c['winner']*3 + c['home_draw']*1 + c['away_draw']*1


# In[78]:


final_listing['final_points'] = final_listing.apply(points, axis =1)
final_listing.head()


# ## Calculating goal points

# In[79]:


# Calculating goals conceded


# In[80]:


home = df[['season', 'home_team', 'goal_home_ft', 'goal_away_ft']]


# In[81]:


home.head()


# In[82]:


home = home.rename(columns = {'goal_away_ft': 'goals_conceded_home'})


# In[83]:


grouped = home.groupby(['home_team', 'season']).sum()
grouped


# In[84]:


# Away


# In[85]:


away = df[['season','away_team', 'goal_away_ft', 'goal_home_ft']]


# In[86]:


away.head()


# In[87]:


away = away.rename(columns = {'goal_home_ft': 'goals_conceded_away'})


# In[88]:


grouped2 = away.groupby(['away_team', 'season']).sum()
grouped2


# In[89]:


grouped = grouped.reset_index()


# In[90]:


grouped = grouped.rename(columns = {'home_team':'team'})


# In[91]:


grouped2 = grouped2.reset_index()


# In[92]:


grouped2 = grouped2.rename(columns = {'away_team':'team'})


# In[93]:


grouped2


# In[94]:


# Merge both dfs


# In[95]:


merged = grouped.merge(right = grouped2, on = ['team', 'season'], how = 'left')


# In[96]:


merged


# In[97]:


merged['total_goals_scored'] = merged['goal_home_ft'] + merged['goal_away_ft']


# In[98]:


merged['total_goals_conceded'] = merged['goals_conceded_home'] + merged['goals_conceded_away']


# In[99]:


merged


# ## Point listing

# In[100]:


final_listing.head()


# In[101]:


final_listing = final_listing.reset_index().rename(columns = {'Team':'team'})


# In[102]:


final_listing = final_listing.set_index('team')


# In[103]:


final_points = final_listing.groupby(['team', 'season']).sum()
final_points.head()


# ## CLASSEMENT

# In[104]:


## Add both dataframes of points vs. goal points


# In[105]:


classement = merged.merge(right = final_points, on = ['team', 'season'], how = 'left')


# In[106]:


final_classement = classement[['team', 'season', 'total_goals_scored', 'total_goals_conceded', 'final_points']]


# In[107]:


### CALCULATE GOALS DIFFERNECE IN CASE OF POINTS EQUALITY (SCORES MINUS CONCEDED)


# In[108]:


final_classement['goal_difference'] = final_classement['total_goals_scored'] - final_classement['total_goals_conceded']


# In[109]:


final_classement.head()


# ## Final table of teams per season

# In[110]:


final_classement.groupby(['season', 'team']).sum().sort_values(by = ['season', 'final_points', 'goal_difference'], ascending = False)


# In[117]:


# Download to csv


# In[118]:


final_classement_grouped = final_classement.groupby(['season', 'team']).sum().sort_values(by = ['season', 'final_points', 'goal_difference'], ascending = False)


# In[120]:


final_classement_grouped.to_csv('final_classement_grouped.csv', sep = ';')


# In[119]:


final_classement


# In[123]:


final_classement.to_csv('final_classement.csv', sep = ';')


# In[111]:


### Split dataframes per season


# In[112]:


season_10 = final_classement[final_classement['season'] == '10/11'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)
season_11 = final_classement[final_classement['season'] == '11/12'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)
season_12 = final_classement[final_classement['season'] == '12/13'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)
season_13 = final_classement[final_classement['season'] == '13/14'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)
season_14 = final_classement[final_classement['season'] == '14/15'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)
season_15 = final_classement[final_classement['season'] == '15/16'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)
season_16 = final_classement[final_classement['season'] == '16/17'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)
season_17 = final_classement[final_classement['season'] == '17/18'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)
season_18 = final_classement[final_classement['season'] == '18/19'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)
season_19 = final_classement[final_classement['season'] == '19/20'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)
season_20 = final_classement[final_classement['season'] == '20/21'].sort_values(by = ['final_points', 'goal_difference'], ascending = False)


# In[113]:


# Focus Arsenal


# In[114]:


ars_season_10 = season_10[season_10['team'] == 'Arsenal']
ars_season_11 = season_11[season_11['team'] == 'Arsenal']
ars_season_12 = season_12[season_12['team'] == 'Arsenal']
ars_season_13 = season_13[season_13['team'] == 'Arsenal']
ars_season_14 = season_14[season_14['team'] == 'Arsenal']
ars_season_15 = season_15[season_15['team'] == 'Arsenal']
ars_season_16 = season_16[season_16['team'] == 'Arsenal']
ars_season_17 = season_17[season_17['team'] == 'Arsenal']
ars_season_18 = season_18[season_18['team'] == 'Arsenal']
ars_season_19 = season_19[season_19['team'] == 'Arsenal']
ars_season_20 = season_20[season_20['team'] == 'Arsenal']


# In[115]:


#list dataframe you want to append
listing = [ars_season_10, ars_season_11, ars_season_12, ars_season_13,
         ars_season_14, ars_season_15, ars_season_16, ars_season_17, ars_season_18,
        ars_season_19, ars_season_20]

#new dataframe to store append result
arsenal_seasons = pd.DataFrame()

for x in listing:
    arsenal_seasons = arsenal_seasons.append(x)


# In[116]:


arsenal_seasons


# In[122]:


arsenal_seasons.to_csv('arsenal_seasons_classement.csv', sep = ';')


# In[ ]:




