#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Base de données SQL d'origine : https://www.kaggle.com/hugomathien/soccer

"""
Ce script permet de se connecter à la base de données SQL téléchargeable par le lien ci-dessus.
Ensuite il permet d'enregistrer chaque table de la base SQL sous forme de fichier csv :
    - Country.csv
    - League.csv
    - Match.csv
    - Player.csv
    - Player_Attributes.csv
    - Team.csv
    - Team_Attributes.csv
"""


# # Script pour transformer une database .sqlite en fichiers csv

# In[ ]:


# Import des packages
import csv    # module permettant l'écriture des fichiers csv
import sqlite3    # module permettant d'interagir avec la database

# Créer un objet de connexion à la database SQL
connection = sqlite3.connect("database.sqlite")    # le fichier .sqlite doit se trouver dans le même dossier que ce script

# Créer un curseur à partir de la connexion (permet d'envoyer des requêtes à la database et de récupérer les résultats)
cursor = connection.cursor()


    ## Table Country

# Méthode 'execute' du curseur pour faire une requête afin de sélectionner tous les champs de la table
cursor.execute('SELECT * FROM Country')

# Récupération des données de la table dans un fichier csv
with open("Country.csv", "w", newline='',encoding="utf-8") as csv_file :
    csv_writer = csv.writer(csv_file, delimiter=',')    # écriture du csv
    csv_writer.writerow([i[0] for i in cursor.description])    # récupérer les en-têtes
    csv_writer.writerows(cursor)
    
    
    ## Table League

cursor.execute('SELECT * FROM League')

with open("League.csv", "w", newline='',encoding="utf-8") as csv_file :
    csv_writer = csv.writer(csv_file, delimiter=',')
    csv_writer.writerow([i[0] for i in cursor.description])
    csv_writer.writerows(cursor)
    
    
    ## Table Match

cursor.execute('SELECT * FROM Match')

with open("Match.csv", "w", newline='',encoding="utf-8") as csv_file :
    csv_writer = csv.writer(csv_file, delimiter=',')
    csv_writer.writerow([i[0] for i in cursor.description])
    csv_writer.writerows(cursor)
    
    
    ## Table Player

cursor.execute('SELECT * FROM Player')

with open("Player.csv", "w", newline='',encoding="utf-8") as csv_file :
    csv_writer = csv.writer(csv_file, delimiter=',')
    csv_writer.writerow([i[0] for i in cursor.description])
    csv_writer.writerows(cursor)
    
    
    ## Table Player_Attributes

cursor.execute('SELECT * FROM Player_Attributes')

with open("Player_Attributes.csv", "w", newline='',encoding="utf-8") as csv_file :
    csv_writer = csv.writer(csv_file, delimiter=',')
    csv_writer.writerow([i[0] for i in cursor.description])
    csv_writer.writerows(cursor)
    
    
    ## Table Team

cursor.execute('SELECT * FROM Team')

with open("Team.csv", "w", newline='',encoding="utf-8") as csv_file :
    csv_writer = csv.writer(csv_file, delimiter=',')
    csv_writer.writerow([i[0] for i in cursor.description])
    csv_writer.writerows(cursor)
    
    
    ## Table Team_Attributes

cursor.execute('SELECT * FROM Team_Attributes')

with open("Team_Attributes.csv", "w", newline='',encoding="utf-8") as csv_file :
    csv_writer = csv.writer(csv_file, delimiter=',')
    csv_writer.writerow([i[0] for i in cursor.description])
    csv_writer.writerows(cursor)
    
    
# Fermer la connection
connection.close()

