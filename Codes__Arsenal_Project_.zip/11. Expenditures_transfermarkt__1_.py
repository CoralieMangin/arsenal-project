#!/usr/bin/env python
# coding: utf-8

# In[1]:


import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from urllib.request import urlopen
import urllib.request # we are going to need to generate a Request object

import requests
from bs4 import BeautifulSoup
from urllib import request as u_r


# In[2]:


pd.options.display.max_rows = 100000
pd.options.display.max_columns = 100000
pd.options.display.float_format = '{:20,.2f}'.format


# In[4]:


# FROM 09/10 season to 21/22
clubs = []
exp = []
arrival = []
income = []
departure = []
balance = []

for i in range(1,11):
    my_url = "https://www.transfermarkt.com/transfers/einnahmenausgaben/statistik/plus/ajax/yw1/ids/a/sa//saison_id/2009/saison_id_bis/2021/land_id//nat//pos//altersklasse//w_s//leihe//intern/0/0//page/" + str(i)
    #https://www.transfermarkt.com/transfers/einnahmenausgaben/statistik/plus/ajax/yw1/ids/a/sa//saison_id/2009/saison_id_bis/2021/land_id//nat//pos//altersklasse//w_s//leihe//intern/0/0//page/" 
        # here we define the headers for the request
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36'}
        # this request object will integrate your URL and the headers defined above
    req = urllib.request.Request(url=my_url, headers=headers)
    tree = requests.get(my_url, headers = headers)
    soup = BeautifulSoup(tree.content, 'html.parser')    
    
    club = soup.findAll(name = 'tr', attrs = {'class': 'even'})
    exps = soup.select('td')
    arrivals = soup.findAll(name = 'tr', attrs = {'class': 'odd'})
    
    for element in club:
        clubs.append(element.text.strip())
    for element2 in exps:
        exp.append(element2.text.strip())
    for element3 in arrivals:
        arrival.append(element3.text.strip())


# In[237]:


exp


# In[238]:


table = exp[22:]


# In[239]:


first = table[:202]


# In[240]:


bin1 = table[202:249]


# In[241]:


second = table[249:451]


# In[242]:


bin2 = table[451:498]


# In[243]:


third = table[498:700]


# In[244]:


bin3 = table[700:747]


# In[245]:


fourth = table[747:949]


# In[246]:


bin4 = table[949:996]


# In[247]:


fifth = table[996:1198]


# In[248]:


bin5 = table[1198:1245]


# In[249]:


sixth = table[1245:1447]


# In[250]:


bin6 = table[1447:1494]


# In[251]:


seven = table[1494:1696]


# In[252]:


bin7 = table[1696:1743]


# In[253]:


eight = table[1743:1945]


# In[254]:


bin8 = table[1945:1992]


# In[255]:


nine = table[1992:2194]


# In[256]:


bin9 = table[2194:2241]


# In[257]:


ten = table[2241:2443]


# In[258]:


bin10 = table[2243:]


# In[259]:


new_table = first+second+third+fourth+fifth+sixth+seven+eight+nine+ten


# In[260]:


new_table


# In[261]:


result = list(filter(None, new_table))


# In[262]:


print(result)


# In[263]:


df = pd.DataFrame(result, columns = ['val'])


# In[264]:


df


# In[265]:


result
np_array = np.array(result)


# In[267]:


reshaped_array = np.reshape(result, (250, 7))


# In[324]:


reshaped_array = np.reshape(result, (250, 7))

df = pd.DataFrame(reshaped_array, columns=["Num", "Club", "Expenditure", "Arrivals", "Income", "Departures", "Balance"])

df


# In[325]:


df = df.drop('Num', axis = 1)


# In[326]:


df


# In[327]:


df.shape


# In[328]:


df.isna().sum()


# In[329]:


# Format euro columns 


# In[330]:


# expenditure column


# In[331]:


df['Expenditure'] = df['Expenditure'].str[1:]


# In[332]:


df['Expenditure'][:13]


# In[333]:


df['Expenditure'][:13] = df['Expenditure'][:13].str.replace('.', '')


# In[334]:


df['Expenditure'][:13] = df['Expenditure'][:13].str.replace('bn','')


# In[335]:


df['Expenditure'][:13] = df['Expenditure'][:13].astype(float)


# In[336]:


df['Expenditure'][:13] = df['Expenditure'][:13]*10**7


# In[337]:


df


# In[338]:


df['Expenditure'][13:] = df['Expenditure'][13:].str[:-1]


# In[339]:


df['Expenditure'][13:] = df['Expenditure'][13:].str.replace('.', '')


# In[340]:


df


# In[341]:


df['Expenditure'][13:] = df['Expenditure'][13:].astype(float)


# In[342]:


df['Expenditure'][13:] = df['Expenditure'][13:]*10**4


# In[345]:


# Income col


# In[346]:


df['Income'] = df['Income'].str[1:]


# In[347]:


df['Income'] = df['Income'].str[:-1]


# In[348]:


df[df['Income'].str.contains("b")]


# In[349]:


df['Income'].iloc[[1,2,3,5,7,27]] = df['Income'].iloc[[1,2,3,5,7,27]].str.replace('b', '')


# In[350]:


df['Income'] = df['Income'].str.replace('.', '')


# In[351]:


df['Income'] = df['Income'].astype(float)*10000


# In[352]:


df['Income'].iloc[[1,2,3,5,7,27]] = df['Income'].iloc[[1,2,3,5,7,27]]*1000


# In[353]:


df['Income']


# In[ ]:


#balance col


# In[355]:


df['Balance'] = df['Balance'].str[1:]


# In[356]:


df['Balance'] = df['Balance'].str[:-1]


# In[357]:


df[df['Balance'].str.contains("b")]


# In[358]:


df['Balance'] = df['Balance'].str.replace('.', '')


# In[359]:


df[df['Balance'].str.contains(",")]


# In[360]:


df['Balance'].iloc[[0, 4]] = df['Balance'].iloc[[0,4]].str.replace(',', '') 


# In[361]:


df[df['Balance'].str.contains("Th")]


# In[362]:


df['Balance'].iloc[[110,121,146,151,181]] = df['Balance'].iloc[[121,151,180]].str.replace('Th', '')


# In[363]:


df['Balance'] = df['Balance'].astype(float)


# In[364]:


df['Balance'] = df['Balance']*10000


# In[365]:


df['Balance'].iloc[[121,151,180]] = df['Balance'].iloc[[121,151,180]] / 10


# In[366]:


df


# In[367]:


df['balance_computed'] = df['Income'] - df['Expenditure']


# In[368]:


df


# In[369]:


df.to_csv('team_exp_2009_2021.csv', sep = ';')


# In[370]:


# From 2009/10 to 2021/22


# In[ ]:




