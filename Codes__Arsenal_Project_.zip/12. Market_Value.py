#!/usr/bin/env python
# coding: utf-8

# In[49]:


import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np


# In[50]:


from urllib.request import urlopen
import urllib.request # we are going to need to generate a Request object

import requests
from bs4 import BeautifulSoup
import pandas as pd
from urllib import request as u_r

my_url = "https://www.transfermarkt.com/vereins-statistik/wertvollstemannschaften/marktwertetop?kontinent_id=0&land_id=0&plus=1"

# here we define the headers for the request
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36'}

# this request object will integrate your URL and the headers defined above
req = urllib.request.Request(url=my_url, headers=headers)

tree = requests.get(my_url, headers = headers)
#print(tree)
soup = BeautifulSoup(tree.content, 'html.parser')


# In[51]:


club_list = soup.findAll(name = 'td', attrs = {'class':'no-border-links hauptlink'})

clubs = []
for element in club_list:
    clubs.append(element.text)


# In[52]:


print(clubs)


# In[53]:


competitions = soup.select('.links')

competition = []
for element in competitions:
    competition.append(element.text)


# In[54]:


print(competition)


# In[55]:


## Remove the title "competition"


# In[56]:


competition.pop(0)


# In[57]:


print(competition)


# In[58]:


#market = soup.findAll(name = 'td', attrs = {'class':'rechts'})

market = soup.select('b')

market_all = []
for element in market: 
    market_all.append(element.text)


# In[59]:


print(market_all)


# In[60]:


market_value = []

for i in market_all[::2]:
    market_value.append(i)
    


# In[61]:


print(market_value)


# In[62]:


mean_market_value_players = []

for i in market_all[1::2]:
    mean_market_value_players.append(i)


# In[63]:


print(mean_market_value_players)


# In[64]:


df= pd.DataFrame(list(zip(clubs,competition,market_value,mean_market_value_players)), 
                 columns=["clubs","competition","market_value","mean_market_value_players"])


# In[65]:


df


# In[66]:


## Fix columns input


# In[67]:


df['market_value'] = df['market_value'].str[:-1]


# In[68]:


df.head()


# In[69]:


df['market_value'].iloc[0] = df['market_value'].iloc[0].replace('€1.08b', '€1.08')


# In[70]:


df


# In[71]:


# Fix NaN input


# In[72]:


df = df.fillna('€375.50')


# In[73]:


df


# In[74]:


df['market_value'] = df['market_value'].str[1:]


# In[75]:


## Clarify col names and measures


# In[76]:


df = df.rename(columns = {'market_value': 'market_value_millions'})


# In[77]:


df = df.rename(columns = {'mean_market_value_players': 'mean_market_value_players_millions'})


# In[78]:


## Fix last column 


# In[79]:


df['mean_market_value_players_millions'] = df['mean_market_value_players_millions'].str[:-1]


# In[80]:


df['mean_market_value_players_millions'] = df['mean_market_value_players_millions'].str[1:]


# In[81]:


df.dtypes


# In[82]:


# Fix col types


# In[83]:


df['market_value_millions'] = df['market_value_millions'].astype('float')
df['mean_market_value_players_millions'] = df['mean_market_value_players_millions'].astype('float')


# In[84]:


df['clubs'] = df['clubs'].astype('str')


# In[85]:


df.head()


# In[86]:


#df['market_value_millions'] = df['market_value_millions'] * 1000000


# In[87]:


df['market_value_millions'].iloc[0] = df['market_value_millions'].iloc[0] *1000


# In[88]:


#df['mean_market_value_players_millions'] = df['mean_market_value_players_millions'] * 10


# In[89]:


df.head()


# In[90]:


df_copy = df 


# In[91]:


df_copy


# In[94]:


team_to_replace = {'Tottenham' : 'Tottenham Hotspur',
                    'Leicester' : 'Leicester City',   
                    'Stoke' : 'Stoke City', 
                    'West Ham' : 'West Ham United', 
                    'Swansea' : 'Swansea City', 
                    'Hull' : 'Hull City', 
                    'Norwich' : 'Norwich City',
                    'Bournemouth' : 'AFC Bournemouth', 
                    'Brighton' : 'Brighton and Hove Albion',
                    'Huddersfield' : 'Huddersfield Town', 
                    'Cardiff' : 'Cardiff City',
                    'Man City' : 'Manchester City',
                    'Man Utd': 'Manchester United',
                    'FC Barcelona': 'Barcelona',
                    'FC Porto': 'Porto', 
                    'Sevilla FC': 'Sevilla',
                    'FC Schalke 04': 'Schalke 04',
                    'FC Nantes' : 'Nantes',
                    'Chelsea FC': 'Chelsea',
                    'Liverpool FC' : 'Liverpool',
                    'Juventus FC' : 'Juventus',
                    'Arsenal FC': 'Arsenal',
                    'Everton FC': 'Everton'}

df_copy['clubs'] = df_copy['clubs'].replace(team_to_replace)


# In[95]:


df_copy


# In[96]:


plt.figure(figsize = (15,30))
sns.catplot(x= 'clubs', y = 'market_value_millions', data = df_copy, height=5, aspect=3)
plt.gca().yaxis.set_major_formatter(plt.matplotlib.ticker.StrMethodFormatter('{x:,.0f}'))

plt.xticks(fontsize = 6, rotation =45)
plt.show(); 


# In[97]:


## Arsenal is number 14 on the list


# In[98]:


df_copy.to_csv('teams_players_market_value.csv', sep= ';')


# In[ ]:




