#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Origine du csv initial : https://www.kaggle.com/pablohfreitas/all-premier-league-matches-20102021

"""
Ce script nettoie et uniformise le csv initial téléchargeable avec le lien ci-dessus : 
    - suppression de colonnes;
    - gestion des valeurs manquantes;
    - mise en forme de la date;
    - etc. 
A la fin, le fichier propre est extrait sous le nom "matchs_premier_league.csv".

Ce script permet également d'extraire un fichier csv avec toutes les équipes de l'English Premier League ayant joué des matchs entre 2010 et 2020.
A la fin, le fichie r est extrait sous le nom "teams_premier_league.csv".
"""


# # Clean du csv contenant les matchs de l'English Premier League de 2010 à 2021

# In[2]:


# Import des modules
import pandas as pd
import numpy as np

# Import du csv et affichage des caractéristiques et des premières lignes
df = pd.read_csv(r"df_full_premierleague.csv")
print(df.info())
df.head(5)


# ## Suppression de données

# In[3]:


# Suppression de la saison 20/21 qui est incomplète
indexNames = df[df['season']=='20/21'].index
df.drop(indexNames, axis=0, inplace=True)

# Suppression de la colonne 'Unnamed: 0' générée lors de la création du csv et d'autres colonnes qui ne seront pas utilisées : 
to_drop = ['Unnamed: 0','link_match','performance_acum_H', 'performance_acum_A', 'performance_acum_home','performance_acum_away']
df.drop(to_drop, axis=1, inplace=True)
df.head(5)


# ## Gestion des NANs

# In[4]:


# Définition d'une fonction pour afficher les valeurs manquantes par colonne

def valeur_manquante(df):
    """
    Cette fonction prend un DataFrame en paramètre et permet d'afficher le nombre de valeurs manquantes pour chaque colonne de celui-ci.
    """
    flag=0
    for col in df.columns:
            if df[col].isna().sum() > 0:
                flag=1
                print(f'"{col}": {df[col].isna().sum()} valeurs manquantes')
    if flag==0:
        print("Le dataset ne contient pas de valeurs manquantes.")
        
valeur_manquante(df)


# In[5]:


# Les NANs sont sur les colonnes de moyenne par matchs, lorsque l'équipe n'avait pas encore joué. On peut les remplacer par la valeur du match correspondant.
df = df.fillna({'clearances_avg_H': df['home_clearances'],'corners_avg_H': df['home_corners'], 'fouls_conceded_avg_H' : df['home_fouls_conceded'], 'offsides_avg_H' : df['home_offsides'], 'passes_avg_H' : df['home_passes'],
                'possession_avg_H' : df['home_possession'], 'red_cards_avg_H' : df['home_red_cards'],'shots_avg_H' :df['home_shots'], 'shots_on_target_avg_H' : df['home_shots_on_target'], 'tackles_avg_H' : df['home_tackles'],
                'touches_avg_H' : df['home_touches'], 'yellow_cards_avg_H' :df['home_yellow_cards'], 'goals_scored_ft_avg_H' : df['goal_home_ft'],'goals_conced_ft_avg_H' : df['goal_away_ft'], 'sg_match_ft_acum_H' : df['sg_match_ft'],
                'goals_scored_ht_avg_H' : df['goal_home_ht'],'goals_conced_ht_avg_H' : df['goal_away_ht'], 'sg_match_ht_acum_H' : df['sg_match_ht'], 'clearances_avg_A' : df['away_clearances'], 'corners_avg_A' : df['away_corners'],
                'fouls_conceded_avg_A' : df['away_fouls_conceded'],'offsides_avg_A' : df['away_offsides'],'passes_avg_A': df['away_passes'], 'possession_avg_A' : df['away_possession'], 'red_cards_avg_A' :df['away_red_cards'],
                'shots_avg_A' : df['away_shots'], 'shots_on_target_avg_A' : df['away_shots_on_target'], 'tackles_avg_A' : df['away_tackles'],'touches_avg_A' : df['away_touches'], 'yellow_cards_avg_A' : df['away_yellow_cards'], 
                'goals_scored_ft_avg_A' : df['goal_away_ft'],'goals_conced_ft_avg_A' : df['goal_home_ft'], 'sg_match_ft_acum_A' : df['sg_match_ft'], 'goals_scored_ht_avg_A' : df['goal_away_ht'],
                'goals_conced_ht_avg_A' : df['goal_home_ft'], 'sg_match_ht_acum_A' : df['sg_match_ht']})

# Les NANs sont également sur les colonnes de moyenne par saison. On peut les remplacer par les valeurs de moyenne par match correspondantes. 
df = df.fillna({'clearances_avg_home' : df['clearances_avg_H'], 'corners_avg_home' : df['corners_avg_H'], 
                'fouls_conceded_avg_home' : df['fouls_conceded_avg_H'],'offsides_avg_home' : df['offsides_avg_H'], 'passes_avg_home' : df['passes_avg_H'], 'possession_avg_home' : df['possession_avg_H'],
                'red_cards_avg_home' : df['red_cards_avg_H'], 'shots_avg_home' : df['shots_avg_H'], 'shots_on_target_avg_home' : df['shots_on_target_avg_H'],'tackles_avg_home' : df['tackles_avg_H'], 
                'touches_avg_home' : df['touches_avg_H'], 'yellow_cards_avg_home' :df['yellow_cards_avg_H'],'goals_scored_ft_avg_home' : df['goals_scored_ft_avg_H'], 'goals_conced_ft_avg_home' : df['goals_conced_ft_avg_H'],
                'sg_match_ft_acum_home' :df['sg_match_ft_acum_H'], 'goals_scored_ht_avg_home' : df['goals_scored_ht_avg_H'],'goals_conced_ht_avg_home':df['goals_conced_ht_avg_H'], 'sg_match_ht_acum_home':df['sg_match_ht_acum_H'],
                'clearances_avg_away' : df['clearances_avg_A'], 'corners_avg_away' :df['corners_avg_A'],'fouls_conceded_avg_away' :df['fouls_conceded_avg_A'], 'offsides_avg_away':df['offsides_avg_A'], 
                'passes_avg_away':df['passes_avg_A'],'possession_avg_away':df['possession_avg_A'],'red_cards_avg_away':df['red_cards_avg_A'],'shots_avg_away':df['shots_avg_A'],'shots_on_target_avg_away':df['shots_on_target_avg_A'], 
                'tackles_avg_away':df['tackles_avg_A'],'touches_avg_away':df['touches_avg_A'],'yellow_cards_avg_away':df['yellow_cards_avg_A'],'goals_scored_ft_avg_away':df['goals_scored_ft_avg_A'],
                'goals_conced_ft_avg_away':df['goals_conced_ft_avg_A'],'sg_match_ft_acum_away':df['sg_match_ft_acum_A'],'goals_scored_ht_avg_away':df['goals_scored_ht_avg_A'],'goals_conced_ht_avg_away':df['goals_conced_ht_avg_A'],
                'sg_match_ht_acum_away':df['sg_match_ht_acum_A']})


# ## Mise en forme de la colonne 'Date' (format Datetime)

# In[6]:


# Date au format datetime et ajout d'une colonne pour l'année
df['date'] = pd.to_datetime(df['date'])
df['year'] = df['date'].dt.year

# Classer par date croissante
df.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)


# ## Ajout de colonnes

# In[7]:


# Définition d'une fonction pour récupérer le nom de l'équipe gagante selon la différence de score et stockage des valeurs dans une nouvelle colonne 'Win'

def winning_team(c):
    """
    Cette fonction prend un seul paramètre (un DataFrame) puis retourne le nom de l'équipe gagnante selon le nombre de buts marqués par chacune des deux équipes.
    Elle prend en considération la possibilité de match nul et retourne alors 'None'.
    """
    if c['goal_home_ft'] > c['goal_away_ft']:
        return c['home_team']
    elif c['goal_home_ft'] < c['goal_away_ft']:
        return c['away_team']
    elif c['goal_home_ft'] == c['goal_away_ft']:
        return 'None'

df['Win'] = df.apply(winning_team, axis= 1)

# Définition d'une fonction pour récupérer le nom de l'équipe perdante selon la différence de score et stockage des valeurs dans une nouvelle colonne 'Loss'

def losing_team(c):
    """
    Cette fonction prend un seul paramètre (un DataFrame) puis retourne le nom de l'équipe perdante selon le nombre de buts marqués par chacune des deux équipes.
    Elle prend en considération la possibilité de match nul et retourne alors 'None'.
    """
    if c['goal_home_ft'] > c['goal_away_ft']:
        return c['away_team']
    elif c['goal_home_ft'] < c['goal_away_ft']:
        return c['home_team']
    elif c['goal_home_ft'] == c['goal_away_ft']:
        return 'None'

df['Loss'] = df.apply(losing_team, axis= 1)

# Définition de 2 fonctions pour récupérer le nom des équipes à domicile et à l'extérieur lors d'égalités

def draw_home(c):
    """
    Cette fonction prend un seul paramètre (un DataFrame) puis retourne le nom de l'équipe à domicile lors d'un match nul.
    """
    if c['goal_home_ft'] == c['goal_away_ft']:
        return c['home_team']
    else :
        'N/A'

def draw_away(c):
    """
    Cette fonction prend un seul paramètre (un DataFrame) puis retourne le nom de l'équipe à l'extérieur lors d'un match nul.
    """
    if c['goal_home_ft'] == c['goal_away_ft']:
        return c['away_team']
    else :
        'N/A'

## Stockage des valeurs dans 2 nouvelles colonnes 'draw_home' et 'draw_away'

df['draw_home'] = df.apply(draw_home, axis= 1)
df['draw_away'] = df.apply(draw_away, axis= 1)

# Définition d'une fonction pour afficher le résultat des matchs pour l'équipe Arsenal

def arsenal_results(c):
    """
    Cette fonction prend un seul paramètre (un DataFrame) puis compare le nombre de buts marqués pour chacune des deux équipes par match, 
    selon qu'Arsenal joue à domicile ou à l'extérieur. 
    Elle retourne le résultat du match du point de vue de l'équipe Arsenal : 'W' en cas de victoire, 'L' en cas de défaite, 'D' en cas d'égalité.
    """
    if (c['home_team'] == 'Arsenal') & (c['goal_home_ft'] > c['goal_away_ft']):
        return 'W'
    elif (c['home_team'] == 'Arsenal') & (c['goal_home_ft'] < c['goal_away_ft']):
        return 'L'
    elif (c['home_team'] == 'Arsenal') & (c['goal_home_ft'] == c['goal_away_ft']):
        return 'D'
    elif (c['away_team'] == 'Arsenal') & (c['goal_home_ft'] > c['goal_away_ft']):
        return 'L'
    elif (c['away_team'] == 'Arsenal') & (c['goal_home_ft'] < c['goal_away_ft']):
        return 'W'
    elif (c['away_team'] == 'Arsenal') & (c['goal_home_ft'] == c['goal_away_ft']):
        return 'D'
    else:
        'N/A'
        
# Stockage des valeurs dans une nouvelle colonne 'arsenal_results'
df['arsenal_results'] = df.apply(arsenal_results, axis=1).astype(str)


# ## Renommer des colonnes

# In[8]:


# Renommer les colonnes 'goal_home_ft' et 'goal_away_ft' en 'home_score' et 'away_score'
df = df.rename(columns={'goal_home_ft':'home_score', 'goal_away_ft':'away_score'})

# Renommer les colonnes 'goal_home_ht' et 'goal_away_ht en 'home_score_ht' et 'away_score_ht'
df = df.rename(columns={'goal_home_ht':'home_score_ht', 'goal_away_ht':'away_score_ht'})

df.head(5)


# ## Remplacer les points par des virgules

# In[9]:


# Méthode 'replace' sur les '.' pour avoir des ',', appliqué à toutes les colonnes de df

df = df.astype(str).apply(lambda x: x.str.replace('.',','))
df.head(5)


# In[10]:


print(df.columns.values)


# ## Exporter le csv

# In[11]:


# Matchs de Premier League (coupe nationale)
df.to_csv(r'clean_csv/matchs_premier_league.csv', index=False)


# ## Extraction d'un fichier contenant les équipes de l'English Premier League

# In[12]:


# On extrait chaque équipe du DataFrame principal
teams = pd.DataFrame(df['home_team'].unique(), columns=['club'])

# On ajoute une colonne 'league' et une colonne 'country'
teams['league'] = 'English Premier League'
teams['country'] = 'England'


# In[13]:


teams.head(5)


# In[14]:


teams['club'].unique()


# In[15]:


# On exporte le csv
# Matchs de Premier League (coupe nationale)
teams.to_csv(r'clean_csv/teams_premier_league.csv', index=False)

