#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Import des packages
from urllib.request import urlopen
from bs4 import BeautifulSoup
import pandas as pd
import requests
import numpy as np


# In[2]:


"""
Ce script permet de webscraper les matchs de Champions League entre 2009 et 2019, en deux DataFrames selon la phase (phase de groupe ou phase éliminatoire).
Ensuite, il les nettoie et les uniformise : 
    - gestion des valeurs manquantes;
    - mise en forme de la date;
    - uniformisation des noms des équipes;
    - etc. 
A la fin, les deux DataFrames sont regroupés et le fichier propre est extrait sous le nom "champions_league.csv".
"""


# # Webscraping des données de Champions League

# ## 1 - Récupération des données dans des DataFrames

# ### Matchs de Champions League de 2009 à 2019- Phases éliminatoires

# In[3]:


# Définition de la page de base à scraper
URL = "https://fr.besoccer.com/competition/resultats/champions"

# Listes vides pour les données que l'on veut scraper
competition = []
date = []
home_team = []
away_team = []
home_score = []
away_score= []

# Début de la boucle pour recréer l'URL des années 2010 à 2019
for i in range(2010,2020) :
    page = requests.get(URL+"/"+str(i))

    # Création de l'objet BeautifulSoup
    soup = BeautifulSoup(page.content, 'html.parser')

    # Scrape competition

    try:
        Comp = soup.findAll('div', attrs={'class':'middle-info ta-c'})
        for element in Comp :
            competition.append(element.text.strip())
    except:
        competition.append(None)

    # Scrape date

    try:
        Dates = soup.findAll('div', attrs={'class':'date'})
        for element in Dates :
            date.append(element.text.strip())
    except:
        date.append(None)

    # Scrape home_team

    try:
        team_h = soup.select(".team_left .name")
        for element in team_h :
            home_team.append(element.text.strip())
    except:
        home_team.append(None)

    # Scrape away_team

    try:
        away_h = soup.select(".team_right .name")
        for element in away_h :
            away_team.append(element.text.strip())
    except:
        away_team.append(None)

    # Scrape home_score

    try:
        Scores_h = soup.findAll('span', attrs={'class':'r1'})
        for element in Scores_h :
            home_score.append(element.text.strip())
    except:
        home_score.append(None)

    # Scrape away_score
    try:
        Scores_a = soup.findAll('span', attrs={'class':'r2'})
        for element in Scores_a :
            away_score.append(element.text.strip())
    except:
        away_score.append(None)

    # Saison suivante et fin de la boucle
    i+=1

# Dictionaire contenant les listes avec le nom des colonnes correspondantes

d={'competition' : competition,
   'date' : date,
   'home_team' : home_team,
   'away_team' : away_team,
   'home_score' : home_score,
   'away_score' : away_score}

# DataFrame à partir du dictionnaire

cl_eliminatories=pd.DataFrame(d)
print(cl_eliminatories.info())
cl_eliminatories.head(5)


# ### Matchs de Champions League de 2009 à 2019 - Phases de groupe

# In[4]:


# Définition de la page de base à scraper
URL = "https://fr.besoccer.com/competition/resultats/champions"

# Listes vides pour les données que l'on veut scraper
competition = []
date = []
home_team = []
away_team = []
home_score = []
away_score= []

# Début de la boucle pour recréer l'URL des années 2009 à 2019
for i in range(2010,2020) :
    URL2 = URL+"/"+str(i)+"/groupeall"
    # Début de la boucle pour recréer l'URL des journées 1 à 6 des phases de groupe
    for j in range(1,7) :
        page = requests.get(URL2+'/journee'+str(j))

        # Création de l'objet BeautifulSoup
        soup = BeautifulSoup(page.content, 'html.parser')

        # Scrape competition

        try:
            Comp = soup.findAll('div', attrs={'class':'middle-info ta-c'})
            for element in Comp :
                competition.append(element.text.strip())
        except:
            competition.append(None)

        # Scrape date

        try:
            Dates = soup.findAll('div', attrs={'class':'date'})
            for element in Dates :
                date.append(element.text.strip())
        except:
            date.append(None)

        # Scrape home_team

        try:
            team_h = soup.select(".team_left .name")
            for element in team_h :
                home_team.append(element.text.strip())
        except:
            home_team.append(None)

        # Scrape away_team

        try:
            away_h = soup.select(".team_right .name")
            for element in away_h :
                away_team.append(element.text.strip())
        except:
            away_team.append(None)

        # Scrape home_score

        try:
            Scores_h = soup.findAll('span', attrs={'class':'r1'})
            for element in Scores_h :
                home_score.append(element.text.strip())
        except:
            home_score.append(None)

        # Scrape away_score
        try:
            Scores_a = soup.findAll('span', attrs={'class':'r2'})
            for element in Scores_a :
                away_score.append(element.text.strip())
        except:
            away_score.append(None)

        # Journée suivante et fin de la boucle
        j+=1
        
    # Saison suivante et fin de la boucle
    i+=1

# Dictionaire contenant les listes avec le noms des colonnes correspondantes

d={'competition': competition,
   'date': date,
   'home_team':home_team,
   'away_team':away_team,
   'home_score':home_score,
   'away_score':away_score}

# DataFrame à partir du dictionnaire

cl_gp=pd.DataFrame(d)
print(cl_gp.info())
cl_gp.head(5)


# ## 2 - Clean des DataFrames obtenus

# ### Gestion des NANs

# In[5]:


# Repérer les valeurs manquantes par colonne

print("Valeurs manquantes cl_eliminatories :", "\n", cl_eliminatories.isna().sum(axis=0), "\n", "\n","Valeurs manquantes cl_gp :", "\n", cl_gp.isna().sum(axis = 0))


# ### Mise en forme de la colonne 'Date' (format YYYY-MM-DD puis Datetime)

# In[6]:


# Séparation des années, mois et jours, stockés dans de nouvelles colonnes

    ## cl_eliminatories
cl_eliminatories['year'] = cl_eliminatories['date'].astype(str).str.split(' ', expand=True)[2]
cl_eliminatories['month'] = cl_eliminatories['date'].astype(str).str.split(' ', expand=True)[1]
cl_eliminatories['day'] = cl_eliminatories['date'].astype(str).str.split(' ', expand=True)[0]

    ## cl_gp
cl_gp['year'] = cl_gp['date'].astype(str).str.split(' ', expand=True)[2]
cl_gp['month'] = cl_gp['date'].astype(str).str.split(' ', expand=True)[1]
cl_gp['day'] = cl_gp['date'].astype(str).str.split(' ', expand=True)[0]

# Remplacement des mois en lettres par des valeurs numériques

    ## cl_eliminatories
date_eliminatories = {'FéV':'02','MAR':'03','AVR':'04','MAI':'05','JUN':'06','AOÛ':'08'}
cl_eliminatories['month'] = cl_eliminatories['month'].replace(date_eliminatories)

    ## cl_gp
date_gp = {'SEP':'09','OCT':'10','NOV':'11','DéC':'12'}
cl_gp['month'] = cl_gp['month'].replace(date_gp)

# Création de la nouvelle colonne 'Date' et suppresion des colonnes 'Month' et 'Day' qui ne serviront plus

    ## cl_eliminatories
cl_eliminatories['date'] = cl_eliminatories['year'].str.cat(cl_eliminatories['month'], sep='-')
cl_eliminatories['date'] = cl_eliminatories['date'].str.cat(cl_eliminatories['day'], sep='-')
cl_eliminatories.drop(['month','day'],axis=1, inplace=True)

    ## cl_gp
cl_gp['date'] = cl_gp['year'].str.cat(cl_gp['month'], sep='-')
cl_gp['date'] = cl_gp['date'].str.cat(cl_gp['day'], sep='-')
cl_gp.drop(['month','day'],axis=1, inplace=True)

# Format Datetime
cl_eliminatories['date'] = pd.to_datetime(cl_eliminatories['date'])
cl_gp['date'] = pd.to_datetime(cl_gp['date'])

# Classement du DataFrame par date croissante et reset de l'index

    ## cl_eliminatories
cl_eliminatories.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)

    ## cl_gp
cl_gp.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)


# ### Mise en forme des colonnes 'Home_team' et 'Away_team'

# In[7]:


# On uniformise le nom des équipes par rapport au DataFrame des matchs de premier league

team_to_replace = {'Man. City':'Manchester City',
                   'Man. Utd':'Manchester United'}

    ## cl_eliminatories
cl_eliminatories['home_team'] = cl_eliminatories['home_team'].replace(team_to_replace)
cl_eliminatories['away_team'] = cl_eliminatories['away_team'].replace(team_to_replace)

    ## cl_gp
cl_gp['home_team'] = cl_gp['home_team'].replace(team_to_replace)
cl_gp['away_team'] = cl_gp['away_team'].replace(team_to_replace)


# ### Ajout de colonnes

# In[8]:


# Ajout de la colonne 'Season' à partir de la colonne 'Year'

    ## cl_eliminatories
season_eliminatories={'2010':'09/10', 
                      '2011':'10/11', 
                      '2012':'11/12', 
                      '2013':'12/13', 
                      '2014':'13/14', 
                      '2015':'14/15', 
                      '2016':'15/16', 
                      '2017':'16/17', 
                      '2018':'17/18', 
                      '2019':'18/19'}

cl_eliminatories['season']=cl_eliminatories['year'].replace(season_eliminatories)

    ## cl_gp
season_gp={'2009':'09/10',
           '2010':'10/11', 
           '2011':'11/12', 
           '2012':'12/13', 
           '2013':'13/14', 
           '2014':'14/15', 
           '2015':'15/16', 
           '2016':'16/17', 
           '2017':'17/18', 
           '2018':'18/19', 
           '2019':'19/20'}

cl_gp['season']=cl_gp['year'].replace(season_gp)

# Ajout de la colonne 'Phase'
cl_eliminatories['phase'] = 'Eliminatories'
cl_gp['phase'] = 'Group'


# ### Format des colonnes

# In[9]:


## cl_eliminatories
cl_eliminatories['competition'] = cl_eliminatories['competition'].astype(str)
cl_eliminatories['home_team'] = cl_eliminatories['home_team'].astype(str)
cl_eliminatories['away_team'] = cl_eliminatories['away_team'].astype(str)
cl_eliminatories['phase'] = cl_eliminatories['phase'].astype(str)
cl_eliminatories['home_score'] = cl_eliminatories['home_score'].astype(float)
cl_eliminatories['away_score'] = cl_eliminatories['away_score'].astype(float)    

## cl_gp
cl_gp['competition'] = cl_gp['competition'].astype(str)
cl_gp['home_team'] = cl_gp['home_team'].astype(str)
cl_gp['away_team'] = cl_gp['away_team'].astype(str)
cl_gp['phase'] = cl_gp['phase'].astype(str)
cl_gp['home_score'] = cl_gp['home_score'].astype(float)
cl_gp['away_score'] = cl_gp['away_score'].astype(float)


# In[10]:


print(cl_eliminatories.info())
cl_eliminatories.head(5)


# In[11]:


print(cl_gp.info())
cl_gp.head(5)


# ## 3 - Regroupement des DataFrames

# In[12]:


champions_league = pd.concat([cl_eliminatories, cl_gp], axis=0)

# Classement par date croissante et reset de l'index

champions_league.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)
print(champions_league.shape)
champions_league.head(5)


# ## 4 - Exporter le csv

# In[13]:


champions_league.to_csv(r'clean_csv/champions_league.csv', index=False)

