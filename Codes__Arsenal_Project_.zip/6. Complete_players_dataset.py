#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Base de données SQL d'origine : https://www.kaggle.com/hugomathien/soccer
# Puis fichiers csv obtenus à partir de la base de données SQL avec le script 'Convert SQLITE database to csv.py'

# Dataset 'players_fifa.csv' issu du script '5. Players_fifa_first'


# In[2]:


"""
Ce script permet de rassembler plusieurs fichiers csv obtenus via les scripts précédents comme indiqué ci-dessus. 

Il va d'abord rassembler plusieurs fichiers csv obtenus depuis une base de données SQL pour créer un DataFrame sur des données de joueurs Fifa, puis le nettoyer et l'uniformiser.

Puis il est combiné avec le premier dataset de données des joueurs Fifa pour obtenir un unique DataFrame de joueurs.
Une seconde étape de nettoyage et d'uniformisation est réalisée. 

Enfin, plusieurs fichiers csv sont extraits : 
    - un DataFrame de référence des équipes : teams_and_leagues.csv
    - un DataFrame des joueurs avec leurs statistiques : total_players.csv
    - un DataFrame des joueurs uniquement de la ligue anglaise et leurs statistiques : players_premier_league.csv
"""


# # Création d'un DataFrame complet sur les joueurs par équipe et leurs statistiques par saison

# In[3]:


# Import des modules

import pandas as pd
import numpy as np


# In[4]:


# Import du premier dataset de joueurs
player1 = pd.read_csv(r'clean_csv/players_fifa.csv')  # On l'utilisera à la toute fin du script pour le compléter et ainsi créer le dernier DataFrame complet

# Import des csv de la base sql
matchs = pd.read_csv(r'Match.csv', index_col=0)
country = pd.read_csv(r'Country.csv')
league = pd.read_csv(r'League.csv', index_col=0)
team = pd.read_csv(r'Team.csv', index_col=0)
player = pd.read_csv(r'Player.csv', index_col=0)
attributes = pd.read_csv(r'Player_Attributes.csv', index_col=0)

# Ces csv sont issus d'une même base de donnée, on peut donc les rejoindre par des colonnes d'id communes
# Tout le but ici est de les regrouper pour ensuite en extraire deux DataFrames :
    # un DataFrame de référence des équipes par ligue par pays
    # un DataFrame de référence complet des joueurs avec tous leurs attributs, que l'on pourra fusionner avec le premier DataFrame fifa pour les années manquantes


# ## 1 - Regroupement des données de matchs, pays, ligue, équipe

# In[5]:


# Nous ferons un lien entre les id des joueurs du DataFrame 'matchs' avec les DataFrames des joueurs par la suite.


# ### A) DataFrame 'matchs' comme base de départ pour regrouper les données

# #### Mise en forme - Un joueur par ligne

# In[6]:


# On extrait du premier DataFrame 'matchs' les colonnes qui nous intéressent

matchs = matchs[['country_id',
                 'league_id',
                 'season',
                 'match_api_id',
                 'home_team_api_id',
                 'home_player_1',
                 'home_player_2',
                 'home_player_3',
                 'home_player_4',
                 'home_player_5',
                 'home_player_6',
                 'home_player_7',
                 'home_player_8',       
                 'home_player_9',                 
                 'home_player_10',                 
                 'home_player_11']]


# In[7]:


# On regroupe l'ensemble des colonnes d'id des joueurs dans une seule colonne 'player_api_id', tout en conservant les autres colonnes. 
# On ne récupère que les équipes et joueurs à domicile car pour chaque compétition il y a un match aller et un match retour, 
# donc la totalité des joueurs et des équipes se trouvent dans les colonnes 'home' et les colonnes 'away'. On évite ainsi d'ajouter des doublons.

df = matchs.groupby(['league_id',
                     'match_api_id',
                     'season', 
                     'home_team_api_id'])['home_player_1',
                                          'home_player_2',
                                          'home_player_3',
                                          'home_player_4',
                                          'home_player_5',
                                          'home_player_6',
                                          'home_player_7',
                                          'home_player_8',
                                          'home_player_9',                                                                         # On récupère les valeurs uniques de chaque colonne 'home_player'
                                          'home_player_10',                                                                        # sous forme d'une liste dans une colonne, puis on reset l'index
                                          'home_player_11'].apply(lambda x: list(np.unique(x))).reset_index(name='player_api_id')  # pour la nommer 'player_api_id'


# In[8]:


# On utilise une méthode pour décomposer les listes en lignes individuelles et ainsi obtenir une ligne par joueur

df = df.explode('player_api_id').reset_index(drop=True)


# #### Standardisation des colonnes

# In[9]:


# On renomme la colonne des id des équipes pour qu'elle soit commune avec les autres DataFrames
df = df.rename(columns={'home_team_api_id':'team_api_id'})

# On standardise la colonne 'season' par rapport aux autres DataFrames, et on ne conserve que les années 2009 à 2014

df['season'] = df['season'].replace({'2008/2009':'08/09',
                                     '2009/2010':'09/10',
                                     '2010/2011':'10/11',
                                     '2011/2012':'11/12',
                                     '2012/2013':'12/13',
                                     '2013/2014':'13/14',
                                     '2014/2015':'14/15',
                                     '2015/2016':'15/16'})

drop1 = df[df['season'] == '08/09'].index
drop2 = df[df['season'] == '14/15'].index
drop3 = df[df['season'] == '15/16'].index
df.drop(drop1, inplace=True)
df.drop(drop2, inplace=True)
df.drop(drop3, inplace=True)

# On supprime la colonne 'match_api_id' qui ne servira plus
df.drop('match_api_id', axis=1, inplace=True)

df.head(5)


# #### Gestion des valeurs manquantes

# In[10]:


# Repérer les valeurs manquantes par colonne

print("Valeurs manquantes :", "\n", df.isna().sum(axis=0))

# Le DataFrame initial 'matchs' contenait de nombreuses valeurs manquantes concernant les joueurs, notamment en 2009, c'est ce qu'on retrouve ici. 
# Comme nous cherchons essentiellement à récupérer les joueurs, nous supprimons toutes les lignes où ces valeurs sont manquantes.

df.dropna(inplace=True)


# ### B) Fusion avec les autres DataFrames

# #### Mise en forme des DataFrames à fusionner

# In[11]:


# On renomme les colonnes communes pour qu'elles correspondent

country = country.rename(columns={'id':'league_id', 
                                 'name':'country'})

league = league.rename(columns={'country_id':'league_id', 
                                 'name':'league'})

# On supprime la colonne 'team_fifa_api_id' du DataFame 'team" car elle ne servira pas
team.drop('team_fifa_api_id', axis=1, inplace=True)


# ####  Fusions successives des DataFrames

# In[12]:


# Regroupement des données de 'league' et 'country' sur la colonne 'league_id'
df_merge1 = pd.merge(league, country, on='league_id')

# Regroupement du résultat avec df (anciennement matchs) sur la colonne 'league_id'
df_merge2 = pd.merge(df, df_merge1, on=['league_id'])

# Regroupement du résultat avec 'team' sur la colonne 'team_api_id'
df1 = pd.merge(df_merge2, team, on='team_api_id')
df1.head(5)

df1.head(5)  # Nous avons un premier aperçu des données que nous pourrons grouper avec les données des joueurs


# ## 2 - Extraction d'un DataFrame de référence des équipes par ligue par pays

# ### Création du DataFrame

# In[13]:


# On extrait les colonnes qui nous intéressent
ref_leagues = df1[['league','team_long_name','team_short_name','country']]

# On supprime les doublons
ref_leagues = ref_leagues.drop_duplicates()
ref_leagues.head(5)


# ## 3 - Regroupement des données sur les joueurs

# In[14]:


# Fusion des deux DataFrames des joueurs sur les colonnes 'player_api_id' et 'player_fifa_api_id'
df = player.merge(attributes, on=['player_api_id','player_fifa_api_id'])

df.head(5)


# ### A) Standardisation des données par rapport au premier dataset de joueurs dont on dispose

# #### Renommer les colonnes

# In[15]:


# On renomme les colonnes par rapport au premier dataset des joueurs fifa pour qu'elles correspondent

df = df.rename(columns={'height':'height_cm', 'overall_rating':'overall',
                        'crossing':'attacking_crossing', 'finishing':'attacking_finishing',
                       'heading_accuracy':'attacking_heading_accuracy', 'short_passing':'attacking_short_passing', 'volleys':'attacking_volleys', 'dribbling':'skill_dribbling', 'curve':'skill_curve',
                       'free_kick_accuracy':'skill_fk_accuracy', 'long_passing':'skill_long_passing', 'ball_control':'skill_ball_control', 
                        'acceleration':'movement_acceleration',
                       'sprint_speed':'movement_sprint_speed', 'agility':'movement_agility', 'reactions':'movement_reactions', 'balance':'movement_balance', 'shot_power':'power_shot_power',
                       'jumping':'power_jumping', 'stamina':'power_stamina', 'strength':'power_strength', 'long_shots':'power_long_shots', 'marking':'defending_marking',
                       'standing_tackle':'defending_standing_tackle', 'sliding_tackle':'defending_sliding_tackle', 'gk_diving':'goalkeeping_diving', 'gk_handling':'goalkeeping_handling',
                       'gk_kicking':'goalkeeping_kicking', 'gk_positioning':'goalkeeping_positioning', 'gk_reflexes':'goalkeeping_reflexes',
                       'aggression':'mentality_aggression', 'interceptions':'mentality_interceptions', 'positioning':'mentality_positioning',
                        'vision':'mentality_vision', 'penalties':'mentality_penalties'})


# #### Mise en forme des dates

# In[16]:


# On ne conserve que les 10 premiers caractères des colonnes 'date' et 'birthday' pour ôter les heures

df['date'] = df['date'].apply(lambda x : x[:10])
df['birthday'] = df['birthday'].apply(lambda x : x[:10])

# On passe les colonnes 'date' et 'birthday' au format datetime puis on trie le dataframe par date croissante

df['birthday'] = pd.to_datetime(df['birthday'])
df['date'] = pd.to_datetime(df['date'])

df.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)


# #### Ajout d'une colonne 'age'

# In[17]:


# Le premier DataFrame des joueurs contient des données d'âgeen plus des dates de naissance
# On calcule l'âge à partir de la date de naissance et de la date du match

df['age'] = (df['date']-df['birthday']).astype('timedelta64[Y]')  # On utilise un timedelta pour obtenir la différence en années plutôt qu'en jours


# #### Ajout d'une colonne 'season'

# In[18]:


# On sélectionne les lignes des périodes qui correspondent à des saisons, puis on y ajoute une colonne 'season' avec la valeur correspondante à la saison

season09 = (df['date'] >= '2009-09-01') & (df['date'] <= '2010-08-31')
df.loc[season09, 'season']='09/10'

season10 = (df['date'] >= '2010-09-01') & (df['date'] <= '2011-08-31')
df.loc[season10, 'season']='10/11'

season11 = (df['date'] >= '2011-09-01') & (df['date'] <= '2012-08-31')
df.loc[season11, 'season']='11/12'

season12 = (df['date'] >= '2012-09-01') & (df['date'] <= '2013-08-31')
df.loc[season12, 'season']='12/13'

season13 = (df['date'] >= '2013-09-01') & (df['date'] <= '2014-08-31')
df.loc[season13, 'season']='13/14'


# ### B) Mise en forme : une seule date par saison pour chaque joueur

# In[19]:


# Dans ce DataFrame il y a plusieurs lignes de données à différentes dates par saison pour chaque joueur
# On ne souhaite en garder qu'une seule, la dernière (la plus représentative des performances du joueur pendant la saison)
# Après vérification le premier DataFrame de joueurs ne contient qu'une ligne par joueur par saison et il s'agit des statistiques en fin de saison donc ça correspond à ce qu'on souhaite faire


# In[20]:


# On isole les données sur la base des saisons
season09 = df[df['season'] == '09/10']
season10 = df[df['season'] == '10/11']
season11 = df[df['season'] == '11/12']
season12 = df[df['season'] == '12/13']
season13 = df[df['season'] == '13/14']


# In[21]:


# On aggrège l'ensemble des données sur la dernière répétition du numéro de joueur 'player_api_id' par saison

season09_grouped = season09.groupby('player_api_id')['season','player_name', 'birthday', 'player_fifa_api_id','height_cm','overall', 'potential', 'preferred_foot',
                                     'attacking_work_rate', 'defensive_work_rate', 'attacking_crossing','attacking_finishing', 'attacking_heading_accuracy',
                                     'attacking_short_passing', 'attacking_volleys', 'skill_dribbling','skill_curve', 'skill_fk_accuracy', 'skill_long_passing',
                                     'skill_ball_control', 'movement_acceleration', 'movement_sprint_speed','movement_agility', 'movement_reactions', 
                                     'movement_balance','power_shot_power', 'power_jumping', 'power_stamina', 'power_strength','power_long_shots', 
                                     'mentality_aggression', 'mentality_interceptions','mentality_positioning', 'mentality_vision', 'mentality_penalties',
                                     'defending_marking', 'defending_standing_tackle','defending_sliding_tackle', 'goalkeeping_diving','goalkeeping_handling',
                                     'goalkeeping_kicking','goalkeeping_positioning', 'goalkeeping_reflexes', 'age'].agg(['last'])

season10_grouped = season10.groupby('player_api_id')['season','player_name', 'birthday', 'player_fifa_api_id','height_cm','overall', 'potential', 'preferred_foot',
                                     'attacking_work_rate', 'defensive_work_rate', 'attacking_crossing','attacking_finishing', 'attacking_heading_accuracy',
                                     'attacking_short_passing', 'attacking_volleys', 'skill_dribbling','skill_curve', 'skill_fk_accuracy', 'skill_long_passing',
                                     'skill_ball_control', 'movement_acceleration', 'movement_sprint_speed','movement_agility', 'movement_reactions', 
                                     'movement_balance','power_shot_power', 'power_jumping', 'power_stamina', 'power_strength','power_long_shots', 
                                     'mentality_aggression', 'mentality_interceptions','mentality_positioning', 'mentality_vision', 'mentality_penalties',
                                     'defending_marking', 'defending_standing_tackle','defending_sliding_tackle', 'goalkeeping_diving','goalkeeping_handling',
                                     'goalkeeping_kicking','goalkeeping_positioning', 'goalkeeping_reflexes', 'age'].agg(['last'])

season11_grouped = season11.groupby('player_api_id')['season','player_name', 'birthday', 'player_fifa_api_id','height_cm','overall', 'potential', 'preferred_foot',
                                     'attacking_work_rate', 'defensive_work_rate', 'attacking_crossing','attacking_finishing', 'attacking_heading_accuracy',
                                     'attacking_short_passing', 'attacking_volleys', 'skill_dribbling','skill_curve', 'skill_fk_accuracy', 'skill_long_passing',
                                     'skill_ball_control', 'movement_acceleration', 'movement_sprint_speed','movement_agility', 'movement_reactions', 
                                     'movement_balance','power_shot_power', 'power_jumping', 'power_stamina', 'power_strength','power_long_shots', 
                                     'mentality_aggression', 'mentality_interceptions','mentality_positioning', 'mentality_vision', 'mentality_penalties',
                                     'defending_marking', 'defending_standing_tackle','defending_sliding_tackle', 'goalkeeping_diving','goalkeeping_handling',
                                     'goalkeeping_kicking','goalkeeping_positioning', 'goalkeeping_reflexes', 'age'].agg(['last'])

season12_grouped = season12.groupby('player_api_id')['season','player_name', 'birthday', 'player_fifa_api_id','height_cm','overall', 'potential', 'preferred_foot',
                                     'attacking_work_rate', 'defensive_work_rate', 'attacking_crossing','attacking_finishing', 'attacking_heading_accuracy',
                                     'attacking_short_passing', 'attacking_volleys', 'skill_dribbling','skill_curve', 'skill_fk_accuracy', 'skill_long_passing',
                                     'skill_ball_control', 'movement_acceleration', 'movement_sprint_speed','movement_agility', 'movement_reactions', 
                                     'movement_balance','power_shot_power', 'power_jumping', 'power_stamina', 'power_strength','power_long_shots', 
                                     'mentality_aggression', 'mentality_interceptions','mentality_positioning', 'mentality_vision', 'mentality_penalties',
                                     'defending_marking', 'defending_standing_tackle','defending_sliding_tackle', 'goalkeeping_diving','goalkeeping_handling',
                                     'goalkeeping_kicking','goalkeeping_positioning', 'goalkeeping_reflexes', 'age'].agg(['last'])

season13_grouped = season13.groupby('player_api_id')['season','player_name', 'birthday', 'player_fifa_api_id','height_cm','overall', 'potential', 'preferred_foot',
                                     'attacking_work_rate', 'defensive_work_rate', 'attacking_crossing','attacking_finishing', 'attacking_heading_accuracy',
                                     'attacking_short_passing', 'attacking_volleys', 'skill_dribbling','skill_curve', 'skill_fk_accuracy', 'skill_long_passing',
                                     'skill_ball_control', 'movement_acceleration', 'movement_sprint_speed','movement_agility', 'movement_reactions', 
                                     'movement_balance','power_shot_power', 'power_jumping', 'power_stamina', 'power_strength','power_long_shots', 
                                     'mentality_aggression', 'mentality_interceptions','mentality_positioning', 'mentality_vision', 'mentality_penalties',
                                     'defending_marking', 'defending_standing_tackle','defending_sliding_tackle', 'goalkeeping_diving','goalkeeping_handling',
                                     'goalkeeping_kicking','goalkeeping_positioning', 'goalkeeping_reflexes', 'age'].agg(['last'])


# Suppression du Multi-index généré par la méthode 'groupby.agg'
season09_grouped.columns = season09_grouped.columns.droplevel(1)
season10_grouped.columns = season10_grouped.columns.droplevel(1)
season11_grouped.columns = season11_grouped.columns.droplevel(1)
season12_grouped.columns = season12_grouped.columns.droplevel(1)
season13_grouped.columns = season13_grouped.columns.droplevel(1)


# In[22]:


# On rassemble les DataFrames horizontalement et on reset l'index

df = pd.concat([season09_grouped,season10_grouped,season11_grouped,season12_grouped,season13_grouped], axis=0, ignore_index=False)
df = df.reset_index()
df.head(5)


# ## 4 - Finalisation du DataFrame complet sur les joueurs

# ### A) Fusion des DataFrames

# In[23]:


# On rassemble le DataFrame avec les attributs des joueurs avec celui contenant l'équipe et la position
final = pd.merge(df, df1, on=['season','player_api_id'])

# Nous pouvons maintenant supprimer les doublons
final = final.drop_duplicates()


# In[24]:


final.head(5)


# ### B) Standardisation des colonnes par rapport au premier dataset de joueurs dont on dispose

# In[25]:


# On supprime toutes les colonnes qui ne sont pas communes avec le premier dataset sur les joueurs
to_drop = ['player_api_id','league_id','team_api_id','league','country','team_short_name', 'attacking_work_rate', 'defensive_work_rate']
final.drop(to_drop, axis=1, inplace=True)

# On renomme les colonnes pour que les noms soient communs
final = final.rename(columns={'team_long_name':'club'})

# Repérer les valeurs manquantes par colonne
print("Valeurs manquantes :", "\n", final.isna().sum(axis=0))

# Les variables 'attacking_volleys', 'skill_curve', 'movement_agility', 'movement_balance', 'power_jumping', 'mentality_vision','defending_sliding_tackle' 
# n'existent pas sur le site sofifa avant la saison 2010/2011. On peut les remplacer par 0.
final[['attacking_volleys', 
       'skill_curve', 
       'movement_agility', 
       'movement_balance', 
       'power_jumping', 
       'mentality_vision',
       'defending_sliding_tackle']] = final[['attacking_volleys', 
                                             'skill_curve', 
                                             'movement_agility', 
                                             'movement_balance', 
                                             'power_jumping', 
                                             'mentality_vision',
                                             'defending_sliding_tackle']].fillna(0)


# ### C) Création du dernier DataFrame complet

# #### Fusion avec le DataFrame 'player1'

# In[26]:


# On passe la colonne 'birthday' de player1 au format datetime

player1['birthday'] = pd.to_datetime(player1['birthday'])


# In[27]:


# Fusion des DataFrames sur les colonnes 'player_fifa_api_id' et 'season'
df = player1.merge(final, 
                   on=['player_name', 'birthday', 'age', 'player_fifa_api_id', 'height_cm', 
                       'club', 'overall', 'potential', 'preferred_foot',
                       'attacking_crossing', 'attacking_finishing', 'attacking_heading_accuracy',
                       'attacking_short_passing', 'attacking_volleys', 'skill_dribbling',
                       'skill_curve', 'skill_fk_accuracy', 'skill_long_passing',
                       'skill_ball_control', 'movement_acceleration', 'movement_sprint_speed',
                       'movement_agility', 'movement_reactions', 'movement_balance',
                       'power_shot_power', 'power_jumping', 'power_stamina', 'power_strength',
                       'power_long_shots', 'mentality_aggression', 'mentality_interceptions',
                       'mentality_positioning', 'mentality_vision', 'mentality_penalties',
                       'defending_marking', 'defending_standing_tackle',
                       'defending_sliding_tackle', 'goalkeeping_diving',
                       'goalkeeping_handling', 'goalkeeping_kicking',
                       'goalkeeping_positioning', 'goalkeeping_reflexes', 'season'], 
                   how='outer')

# Gestion des valeurs manquantes
print("Valeurs manquantes :", "\n", df.isna().sum(axis=0))

# Les colonnes 'value_eur' et 'wage_eur' sont malheureusement inexistantes dans le second DataFrame,
# mais ces données peuvent être intéressantes même si on ne les a qu'à partir de 2015.
# Avant 2015 on peut remplacer les valeurs manquantes par 0.

df = df.fillna(0)


# #### Uniformisation des noms des joueurs

# In[28]:


# Certains joueurs sont probablement en doublon à cause de différences d'écriture de leur nom


# In[29]:


# Pour uniformiser les noms des joueurs, on extrait les colonnes d'id et de nom des joueurs des deux DataFrames avant la fusion
player_name = final[['player_fifa_api_id', 'player_name']]
player_name2 =player1[['player_fifa_api_id', 'player_name']]


# In[30]:


# On rassemble le tout dans un nouveau DataFrame sur la colonne d'id
play = player_name.merge(player_name2, 
                       on=['player_fifa_api_id'],
                       how='outer')

# On ôte les éventuels doublons
play.drop_duplicates(inplace=True)

# On obtient deux colonnes 'player_name', on regarde laquelle contient le moins de valeurs manquantes
play.isna().sum(axis=0)

# On l'utilise pour commpléter les valeurs manquantes de l'autre colonne
play['player_name_x'] = play['player_name_x'].fillna(play['player_name_y'])

# Le DataFrame ainsi complété permet la correspondance id et nom. On supprime la seconde colonne de noms devenue inutile.
play.drop('player_name_y', axis=1, inplace=True)

# On renomme la colonne des noms restante
play = play.rename(columns={'player_name_x':'player_name'})


# In[31]:


# Dans le DataFrame qui contient la totalité des joueurs, 
# on supprime l'ancienne colonne des noms, puis on le fusionne avec le DataFrame tout juste obtenu
df.drop('player_name', axis=1, inplace=True)
total_players = df.merge(play, 
                         on=['player_fifa_api_id'], 
                         how='outer')


# #### Uniformisation des noms des équipes

# In[32]:


# Certaines équipes sont probablement en doublon à cause de différences d'écriture de leur nom entre les deux datasets fusionnés


# In[33]:


print(sorted(total_players['club'].unique()))


# In[34]:


# On remplace les noms différents par un nom commun
# Ici nous admettons que la méthode manuelle, plus laborieuse, implique des manquements
# Néanmoins en l'absence de meilleur méthode pour effectuer ceci, nous pouvons toujours vérifier les différences les plus évidentes (différence d'accent ou de tiret par exemple)
# Et s'il y a des manquements sur des "petits" clubs, cela n'impactera pas nos analyses puisqu'elles ne porteront pas sur ces clubs
new_club = {'FC Bayern München':'FC Bayern Munich',
            'Real Madrid':'Real Madrid CF',
            'AC Arles Avignon' : 'AC Arles-Avignon',
            'AS Nancy Lorraine' : 'AS Nancy-Lorraine',
            'FC Barcelona B' : 'FC Barcelona', 
            'FC Basel 1893' : 'FC Basel', 
            'FC Lausanne-Sport' : 'FC Lausanne-Sports',
            'Montpellier HSC' : 'Montpellier Hérault SC',
            'Real Valladolid CF' : 'Real Valladolid', 
            'Toulouse Football Club' : 'Toulouse FC'}

total_players['club'] = total_players['club'].replace(new_club)


# #### Uniformisation des positions des joueurs

# In[35]:


total_players['position'].unique()  # Il y a de nombreuses positions individuelles, parfois écrites différemment. On veut simplifier ces données pour clarifier l'information


# In[36]:


# On crée des groupes de positions par rôle sur le terrain pour remplacer les positions individuelles correspondantes

attackers = ['ST','CF','RS','LS','RF','LF']  # Les attaquants
attacking_mid = ['CAM','LW','LM','RW','LAM','RM','RAM']  # Les attaquantes centraux
midfielders = ['CM','RCM','LCM']  # Les centraux
defending_mid = ['LDM','CDM','RDM']  # Les défenseurs centraux
defenders = ['CB','LB','RB','LWB','RWB','LCB','RCB']  # Les défenseurs
substitutes = ['RES','SUB']  # Les remplaçants
# Pour le gardien, on conserve 'GK'

# On remplace les positions individuelles par les rôles en utilisant les listes qu'on vient de définir
total_players.replace(attackers,'attacker', inplace=True)
total_players.replace(attacking_mid,'attacking_mid_or_wings', inplace=True)
total_players.replace(midfielders,'midfielder', inplace=True)
total_players.replace(defending_mid,'defending_mid', inplace=True)
total_players.replace(defenders,'defender', inplace=True)
total_players.replace(substitutes,'substitute', inplace=True)


# #### Réindexation des colonnes

# In[37]:


# On réindexe les colonnes dans l'ordre souhaité

total_players = total_players.reindex(columns=['player_fifa_api_id', 'player_name', 'birthday',
                                               'season', 'age', 'position', 'club', 'height_cm',
                                               'overall', 'potential', 'value_eur', 'wage_eur',
                                               'preferred_foot', 'attacking_crossing',
                                               'attacking_finishing', 'attacking_heading_accuracy',
                                               'attacking_short_passing', 'attacking_volleys', 'skill_dribbling',
                                               'skill_curve', 'skill_fk_accuracy', 'skill_long_passing',
                                               'skill_ball_control', 'movement_acceleration', 'movement_sprint_speed',
                                               'movement_agility', 'movement_reactions', 'movement_balance',
                                               'power_shot_power', 'power_jumping', 'power_stamina', 'power_strength',
                                               'power_long_shots', 'mentality_aggression', 'mentality_interceptions',
                                               'mentality_positioning', 'mentality_vision', 'mentality_penalties',
                                               'defending_marking', 'defending_standing_tackle',
                                               'defending_sliding_tackle', 'goalkeeping_diving',
                                               'goalkeeping_handling', 'goalkeeping_kicking',  
                                               'goalkeeping_positioning', 'goalkeeping_reflexes'])


# #### Suppression des doublons

# In[38]:


# On supprime les doublons
total_players.drop_duplicates(inplace=True)

total_players.head(5)


# ## Remplacer les points par des virgules

# In[39]:


# Méthode 'replace' sur les '.' pour avoir des ',', appliqué à toutes les colonnes de df

total_players = total_players.astype(str).apply(lambda x: x.str.replace('.',','))
total_players.head(5)


# ## 5 - Exporter les csv

# In[40]:


# DataFrame de référence des équipes par ligue par pays
ref_leagues.to_csv(r'clean_csv/teams_and_leagues.csv', index=False)

# DataFrame des joueurs par équipe et leurs statistiques par saison
total_players.to_csv(r'clean_csv/total_players.csv', index=False)


# ## Extraction d'un fichier contenant les joueurs de l'English Premier League

# In[41]:


# On extrait chaque joueur des équipes de l'English Premier League dans un nouveau DataFrame
players_premier_league = total_players.loc[total_players['club'].isin(['Wolverhampton Wanderers', 'Wigan Athletic', 
                                                                       'Tottenham Hotspur','Sunderland', 'Chelsea', 
                                                                       'Bolton Wanderers', 'Blackburn Rovers',
                                                                       'Aston Villa', 'Liverpool', 'Manchester United', 
                                                                       'Birmingham City','Arsenal', 'Everton', 
                                                                       'Stoke City', 'West Bromwich Albion',
                                                                       'West Ham United', 'Newcastle United', 'Fulham', 
                                                                       'Manchester City','Blackpool', 'Queens Park Rangers',
                                                                       'Swansea City', 'Norwich City',
                                                                       'Reading', 'Southampton', 'Crystal Palace', 'Hull City',
                                                                       'Cardiff City', 'Leicester City', 'Burnley', 'AFC Bournemouth',
                                                                       'Watford', 'Middlesbrough', 'Brighton and Hove Albion',
                                                                       'Huddersfield Town', 'Sheffield United'])]


# In[42]:


players_premier_league.head(5)


# In[43]:


players_premier_league['club'].unique()


# In[44]:


# On exporte le csv
# Joueurs de Premier League
players_premier_league.to_csv(r'clean_csv/players_premier_league.csv', index=False)

