#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Import des packages
from urllib.request import urlopen
from bs4 import BeautifulSoup
import pandas as pd
import requests
import numpy as np


# In[2]:


"""
Ce script permet de webscraper les matchs de FA Cup entre 2009 et 2019, en deux DataFrames selon la phase (phase de groupe ou phase éliminatoire).
Ensuite, il les nettoie et les uniformise : 
    - gestion des valeurs manquantes;
    - mise en forme de la date;
    - uniformisation des noms des équipes;
    - etc. 
A la fin, les deux DataFrames sont regroupés et le fichier propre est extrait sous le nom "FA_cup.csv".
"""


# # Webscraping des données de FA Cup

# ## 1 - Récupération des données dans des DataFrames

# ### Définition des fonctions : pour le webscraping et pour nettoyer les données avant de créer le dataframe
# 
# ##### Dans cette compétition le nombre de jours en phase de groupe et éliminatoire change à chaque saison.
# ##### On va définir une fonction pour scraper les données à partir de ces paramètres : un URL et les numéros du premier jour (x), puis du dernier jour plus un (y)

# In[3]:


# Définition de la page de base à scraper
URL = "https://fr.besoccer.com/competition/resultats/fa_cup"

# Définition de la fonction pour scraper les données

def Webscraping (URL, x, y) :
    """
    Cette fonction prend en paramètres un URL, le numéro du premier jour (x) et le numéro du dernier jour +1 (y).
    Elle permet de webscraper les données d'un URL donné et des numéros des journées de la phase.
    Concrètement, elle va modifier l'URL à l'aide d'une boucle pour y ajouter le numéro de la journée dans la compétition (exemple : URL + 'journee' + x).
    La fonction va faire une boucle sur le nombre de journées que l'on a déterminé en paramètres à l'aide de 2 bornes x et y. 
    Par exemple, si les matchs qui nous intéressent se déroulent lors des journées 1 à 3, on utilisera les valeurs x=1 et y=4.
    Les données seront alors webscrapées par une boucle sur la journée 1 (URL+'journee'+'1'), puis sur la journée 2 (URL+'journee'+'2'), et enfin sur la journée 3 (URL+'journee'+'3'). 
    """
        
    # Début de la boucle pour recréer l'URL des journées
    for j in range(x,y) : 
        page = requests.get(URL+'/journee'+str(j))
    
        # Création de l'objet BeautifulSoup
        soup = BeautifulSoup(page.content, 'html.parser')

        # Scrape competition
        try:
            Comp = soup.findAll('div', attrs={'class':'middle-info ta-c'})
            for element in Comp :
                competition.append(element.text.strip())
        except:
            competition.append(None)

        # Scrape date
        try:
            Dates = soup.findAll('div', attrs={'class':'date'})
            for element in Dates :
                date.append(element.text.strip())
        except:
            date.append(None)

        # Scrape home_team
        try:
            team_h = soup.select(".team_left .name")
            for element in team_h :
                home_team.append(element.text.strip())
        except:
            home_team.append(None)

        # Scrape away_team
        try:
            away_h = soup.select(".team_right .name")
            for element in away_h :
                away_team.append(element.text.strip())
        except:
            away_team.append(None)

        # Scrape home_score
        try:
            Scores = soup.findAll('div', attrs={'class':'marker'})
            for element in Scores :
                first_score.append(element.text.strip())
        except:
            first_score.append(None)

# Définition d'une fonction pour nettoyer la liste des scores de tous les caractères indésirables

def clean_score(liste) :
    """
    Cette fonction prend en argument une liste puis effectue un "nettoyage" des valeurs de score en plusieurs étapes. 
    Elle récupère les valeurs entre parenthèses puis ne conserve que les valeurs sans espaces. 
    """
    for indice, element in enumerate(liste):
        if '(' in element :
            new_score = element.split('(')[1]
            liste[indice] = new_score
        else : 
            pass
    for indice, element in enumerate(liste):
        if ')' in element :
            new_score = element.split(')')[0]
            liste[indice] = new_score
        else : 
            pass
    for elements in liste :
        if ' ' not in elements : 
            score.append(elements)


# ### Matchs de FA Cup de 2009 à 2019 - Phases éliminatoires

# In[4]:


# Listes vides pour les données que l'on veut scraper
competition = []
date = []
home_team = []
away_team = []
first_score= []

## URLS des saisons de 2009/10 à 2018/19 et application de la fonction Webscraping sur les journées de phase éliminatoire
URL_2010 = URL+"/2010/groupe0"
Webscraping(URL_2010, 3, 9) # Journées 3 à 8

URL_2011 = URL+"/2011/groupe0"
Webscraping(URL_2011, 3, 9) # Journées 3 à 8

URL_2012 = URL+"/2012/groupe0"
Webscraping(URL_2012, 3, 9) # Journées 3 à 8

URL_2013 = URL+"/2013/groupe0"
Webscraping(URL_2013, 3, 9) # Journées 3 à 8

URL_2014 = URL+"/2014/groupe0"
Webscraping(URL_2014, 5, 11) # Journées 5 à 10

URL_2015 = URL+"/2015/groupe0"
Webscraping(URL_2015, 11, 17) # Journées 11 à 16

URL_2016 = URL+"/2016/groupe0"
Webscraping(URL_2016, 17, 23) # Journées 17 à 22

URL_2017 = URL+"/2017/groupe0"
Webscraping(URL_2017, 12, 18) # Journées 12 à 17

URL_2018 = URL+"/2018/groupe0"
Webscraping(URL_2018, 9, 15) # Journées 9 à 14

URL_2019 = URL+"/2019/groupe0"
Webscraping(URL_2019, 9, 15) # Journées 9 à 14

# Nettoyer la liste des scores des caractères indésirables
score = []
clean_score(first_score)

# Dictionaire contenant les listes avec le noms des colonnes correspondantes

d={'competition' : competition,
   'date' : date,
   'home_team' : home_team,
   'away_team' : away_team,
   'score' : score}

# DataFrame à partir du dictionnaire

fa_eliminatories=pd.DataFrame(d)
print(fa_eliminatories.info())
fa_eliminatories.head(5)


# ### Matchs de FA Cup de 2009 à 2019 - Phases de groupe

# In[5]:


# Listes vides pour les données que l'on veut scraper
competition = []
date = []
home_team = []
away_team = []
first_score= []

## Application de la fonction Webscraping sur les journées de phase de groupe (les URLs n'ont pas changé)

Webscraping(URL_2010, 1, 3) # Journées 1 à 2
Webscraping(URL_2011, 1, 3) # Journées 1 à 2
Webscraping(URL_2012, 1, 3) # Journées 1 à 2
Webscraping(URL_2013, 1, 3) # Journées 1 à 2
Webscraping(URL_2014, 1, 5) # Journées 1 à 4
Webscraping(URL_2015, 1, 11) # Journées 1 à 10
Webscraping(URL_2016, 1, 17) # Journées 1 à 16
Webscraping(URL_2017, 1, 12) # Journées 1 à 11
Webscraping(URL_2018, 1, 9) # Journées 1 à 8
Webscraping(URL_2019, 1, 9) # Journées 1 à 8

# Nettoyer la liste des scores des caractères indésirables
score = []
clean_score(first_score)

# Dictionaire contenant les listes avec le noms des colonnes correspondantes

d={'competition' : competition,
   'date' : date,
   'home_team' : home_team,
   'away_team' : away_team,
   'score' : score}

# DataFrame à partir du dictionnaire

fa_gp=pd.DataFrame(d)
print(fa_gp.info())
fa_gp.head(5)


# ## 2 - Clean des DataFrames obtenus

# ### Gestion des NANs

# In[6]:


# Repérer les valeurs manquantes par colonne

print("Valeurs manquantes fa_eliminatories :", "\n", fa_eliminatories.isna().sum(axis=0), "\n", "\n","Valeurs manquantes fa_gp :", "\n", fa_gp.isna().sum(axis = 0))


# ### Mise en forme de la colonne 'Date' (format YYYY-MM-DD puis Datetime)

# In[7]:


#### Séparation des années, mois et jours, stockés dans de nouvelles colonnes

    ## fa_eliminatories
fa_eliminatories['year'] = fa_eliminatories['date'].astype(str).str.split(' ', expand=True)[2]
fa_eliminatories['month'] = fa_eliminatories['date'].astype(str).str.split(' ', expand=True)[1]
fa_eliminatories['day'] = fa_eliminatories['date'].astype(str).str.split(' ', expand=True)[0]

    ## fa_gp
fa_gp['year'] = fa_gp['date'].astype(str).str.split(' ', expand=True)[2]
fa_gp['month'] = fa_gp['date'].astype(str).str.split(' ', expand=True)[1]
fa_gp['day'] = fa_gp['date'].astype(str).str.split(' ', expand=True)[0]

# Remplacement des mois en lettres par des valeurs numériques
dates_to_replace = {'JAN':'01','FéV':'02','MAR':'03','AVR':'04','MAI':'05','AOû':'08','Aoû':'08','SEP':'09','OCT':'10','NOV':'11','DéC':'12'}

fa_eliminatories['month'] = fa_eliminatories['month'].replace(dates_to_replace)
fa_gp['month'] = fa_gp['month'].replace(dates_to_replace)

# Création de la nouvelle colonne 'Date' et suppresion des colonnes 'Month' et 'Day' qui ne serviront plus

    ## fa_eliminatories

fa_eliminatories['date'] = fa_eliminatories['year'].str.cat(fa_eliminatories['month'], sep='-')
fa_eliminatories['date'] = fa_eliminatories['date'].str.cat(fa_eliminatories['day'], sep='-')
fa_eliminatories.drop(['month','day'],axis=1, inplace=True)

    ## fa_gp

fa_gp['date'] = fa_gp['year'].str.cat(fa_gp['month'], sep='-')
fa_gp['date'] = fa_gp['date'].str.cat(fa_gp['day'], sep='-')
fa_gp.drop(['month','day'],axis=1, inplace=True)

# Format Datetime
fa_eliminatories['date'] = pd.to_datetime(fa_eliminatories['date'])
fa_gp['date'] = pd.to_datetime(fa_gp['date'])

# Classement du DataFrame par date croissante et reset de l'index
fa_eliminatories.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)
fa_gp.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)


# ### Mise en forme des colonnes 'Home_team' et 'Away_team'

# In[8]:


# On uniformise le nom des équipes par rapport au DataFrame des matchs de premier league

team_to_replace = {'Man. City':'Manchester City',
                   'Man. Utd':'Manchester United',
                    'Newcastle':'Newcastle United',
                    'West Ham':'West Ham United',
                    'Leicester':'Leicester City',
                    'Wolves':'Wolverhampton Wanderers'}

    ## fa_eliminatories

fa_eliminatories['home_team'] = fa_eliminatories['home_team'].replace(team_to_replace)
fa_eliminatories['away_team'] = fa_eliminatories['away_team'].replace(team_to_replace)

    ## fa_gp

fa_gp['home_team'] = fa_gp['home_team'].replace(team_to_replace)
fa_gp['away_team'] = fa_gp['away_team'].replace(team_to_replace)


# ### Ajout de colonnes

# In[9]:


# Ajout de la colonne 'Season'

    ## fa_eliminatories

season09 = (fa_eliminatories['date'] > '2009-08-02') & (fa_eliminatories['date'] < '2010-08-01')
fa_eliminatories.loc[season09, 'season']='09/10'

season10 = (fa_eliminatories['date'] > '2010-08-02') & (fa_eliminatories['date'] < '2011-08-01')
fa_eliminatories.loc[season10, 'season']='10/11'

season11 = (fa_eliminatories['date'] > '2011-08-02') & (fa_eliminatories['date'] < '2012-08-01')
fa_eliminatories.loc[season11, 'season']='11/12'

season12 = (fa_eliminatories['date'] > '2012-08-02') & (fa_eliminatories['date'] < '2013-08-01')
fa_eliminatories.loc[season12, 'season']='12/13'

season13 = (fa_eliminatories['date'] > '2013-08-02') & (fa_eliminatories['date'] < '2014-08-01')
fa_eliminatories.loc[season13, 'season']='13/14'

season14 = (fa_eliminatories['date'] > '2014-08-02') & (fa_eliminatories['date'] < '2015-08-01')
fa_eliminatories.loc[season14, 'season']='14/15'

season15 = (fa_eliminatories['date'] > '2015-08-02') & (fa_eliminatories['date'] < '2016-08-01')
fa_eliminatories.loc[season15, 'season']='15/16'

season16 = (fa_eliminatories['date'] > '2016-08-02') & (fa_eliminatories['date'] < '2017-08-01')
fa_eliminatories.loc[season16, 'season']='16/17'

season17 = (fa_eliminatories['date'] > '2017-08-02') & (fa_eliminatories['date'] < '2018-08-01')
fa_eliminatories.loc[season17, 'season']='17/18'

season18 = (fa_eliminatories['date'] > '2018-08-02') & (fa_eliminatories['date'] < '2019-08-01')
fa_eliminatories.loc[season18, 'season']='18/19'

    ## fa_gp

season09 = (fa_gp['date'] > '2009-08-02') & (fa_gp['date'] < '2010-08-01')
fa_gp.loc[season09, 'season']='09/10'

season10 = (fa_gp['date'] > '2010-08-02') & (fa_gp['date'] < '2011-08-01')
fa_gp.loc[season10, 'season']='10/11'

season11 = (fa_gp['date'] > '2011-08-02') & (fa_gp['date'] < '2012-08-01')
fa_gp.loc[season11, 'season']='11/12'

season12 = (fa_gp['date'] > '2012-08-02') & (fa_gp['date'] < '2013-08-01')
fa_gp.loc[season12, 'season']='12/13'

season13 = (fa_gp['date'] > '2013-08-02') & (fa_gp['date'] < '2014-08-01')
fa_gp.loc[season13, 'season']='13/14'

season14 = (fa_gp['date'] > '2014-08-02') & (fa_gp['date'] < '2015-08-01')
fa_gp.loc[season14, 'season']='14/15'

season15 = (fa_gp['date'] > '2015-08-02') & (fa_gp['date'] < '2016-08-01')
fa_gp.loc[season15, 'season']='15/16'

season16 = (fa_gp['date'] > '2016-08-02') & (fa_gp['date'] < '2017-08-01')
fa_gp.loc[season16, 'season']='16/17'

season17 = (fa_gp['date'] > '2017-08-02') & (fa_gp['date'] < '2018-08-01')
fa_gp.loc[season17, 'season']='17/18'

season18 = (fa_gp['date'] > '2018-08-02') & (fa_gp['date'] < '2019-08-01')
fa_gp.loc[season18, 'season']='18/19'

# Ajout de la colonne 'phase'
fa_eliminatories['phase'] = 'Eliminatories'
fa_gp['phase'] = 'Group'


# ### Split de la colonne 'Score' en colonnes 'Home_score' et 'Away_score'

# In[10]:


## fa_eliminatories

fa_eliminatories['home_score'] = fa_eliminatories['score'].str.split('-', expand=True)[0].astype(float)
fa_eliminatories['away_score'] = fa_eliminatories['score'].str.split('-', expand=True)[1].astype(float)
fa_eliminatories.drop('score', axis=1, inplace=True)

## fa_gp

# Suppression des lignes dont le score ('16:00') correspond à l'heure de matchs annulés
fa_gp.drop(fa_gp[fa_gp['score'] == '16:00'].index, inplace=True)

# Split du score en deux colonnes
fa_gp['home_score'] = fa_gp['score'].str.split('-', expand=True)[0].astype(float)
fa_gp['away_score'] = fa_gp['score'].str.split('-', expand=True)[1].astype(float)
fa_gp.drop('score', axis=1, inplace=True)


# ### Réindexation des colonnes

# In[11]:


fa_eliminatories = fa_eliminatories.reindex(columns=['competition','date','home_team','away_team','home_score','away_score','year','season','phase'])
fa_gp = fa_gp.reindex(columns=['competition','date','home_team','away_team','home_score','away_score','year','season','phase'])


# ### Format des colonnes

# In[12]:


## fa_eliminatories

fa_eliminatories['competition'] = fa_eliminatories['competition'].astype(str)
fa_eliminatories['home_team'] = fa_eliminatories['home_team'].astype(str)
fa_eliminatories['away_team'] = fa_eliminatories['away_team'].astype(str)
fa_eliminatories['phase'] = fa_eliminatories['phase'].astype(str)
fa_eliminatories['home_score'] = fa_eliminatories['home_score'].astype(float)
fa_eliminatories['away_score'] = fa_eliminatories['away_score'].astype(float)  

## fa_gp

fa_gp['competition'] = fa_gp['competition'].astype(str)
fa_gp['home_team'] = fa_gp['home_team'].astype(str)
fa_gp['away_team'] = fa_gp['away_team'].astype(str)
fa_gp['phase'] = fa_gp['phase'].astype(str)
fa_gp['home_score'] = fa_gp['home_score'].astype(float)
fa_gp['away_score'] = fa_gp['away_score'].astype(float)    


# In[13]:


print(fa_eliminatories.info())
fa_eliminatories.head(5)


# In[14]:


print(fa_gp.info())
fa_gp.head(5)


# ## 3 - Regroupement des DataFrames

# In[15]:


fa_cup = pd.concat([fa_eliminatories, fa_gp], axis=0)

# Classement par date croissante et reset de l'index

fa_cup.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)
print(fa_cup.shape)
fa_cup.tail(5)


# In[16]:


fa_cup.info()


# ## 4 - Exporter le csv

# In[17]:


fa_cup.to_csv(r'clean_csv/FA_cup.csv', index=False)

