#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Import des packages
from urllib.request import urlopen
from bs4 import BeautifulSoup
import pandas as pd
import requests
import numpy as np


# In[2]:


"""
Ce script permet de webscraper les matchs d'Europa League entre 2009 et 2019, en deux DataFrames selon la phase (phase de groupe ou phase éliminatoire).
Ensuite, il les nettoie et les uniformise : 
    - gestion des valeurs manquantes;
    - mise en forme de la date;
    - uniformisation des noms des équipes;
    - etc. 
A la fin, les deux DataFrames sont regroupés et le fichier propre est extrait sous le nom "europa_league.csv".
"""


# # Scraping des données d'Europa League

# ## 1 - Récupération des données dans des DataFrames

# ### Matchs d'Europa League de 2009 à 2019- Phases éliminatoires

# In[3]:


# Définition de la page de base à scraper
URL = "https://fr.besoccer.com/competition/resultats/uefa"

# Listes vides pour les données que l'on veut scraper
competition = []
date = []
home_team = []
away_team = []
first_score= []

# Début de la boucle pour recréer l'URL des années 2010 à 2019
for i in range(2010,2020) :
    page = requests.get(URL+"/"+str(i))

    # Création de l'objet BeautifulSoup
    soup = BeautifulSoup(page.content, 'html.parser')

    # Scrape competition

    try:
        Comp = soup.findAll('div', attrs={'class':'middle-info ta-c'})
        for element in Comp :
            competition.append(element.text.strip())
    except:
        competition.append(None)

    # Scrape date

    try:
        Dates = soup.findAll('div', attrs={'class':'date'})
        for element in Dates :
            date.append(element.text.strip())
    except:
        date.append(None)

    # Scrape home_team

    try:
        team_h = soup.select(".team_left .name")
        for element in team_h :
            home_team.append(element.text.strip())
    except:
        home_team.append(None)

    # Scrape away_team

    try:
        away_h = soup.select(".team_right .name")
        for element in away_h :
            away_team.append(element.text.strip())
    except:
        away_team.append(None)

    # Scrape score

    try:
        Scores = soup.findAll('div', attrs={'class':'marker'})
        for element in Scores :
            first_score.append(element.text.strip())
    except:
        first_score.append(None)

    # Saison suivante et fin de la boucle
    i+=1

# Fonction pour nettoyer la liste des scores de tous les caractères indésirables
score=[]
def clean_score(liste) :
    """
    Cette fonction prend en argument une liste puis effectue un "nettoyage" des valeurs en plusieurs étapes. 
    Elle récupère d'abord les valeurs entre parenthèses puis ne conserve que les valeurs sans espaces. 
    """
    for indice, element in enumerate(liste):
        if '(' in element :
            new_score = element.split('(')[1]
            liste[indice] = new_score
        else : 
            pass
    for indice, element in enumerate(liste):
        if ')' in element :
            new_score = element.split(')')[0]
            liste[indice] = new_score
        else : 
            pass
    for elements in liste :
        if ' ' not in elements : 
            score.append(elements)

clean_score(first_score)

# Dictionaire contenant les listes avec le noms des colonnes correspondantes

d={'competition' : competition,
   'date' : date,
   'home_team' : home_team,
   'away_team' : away_team,
   'score' : score}

# DataFrame à partir du dictionnaire

el_eliminatories=pd.DataFrame(d)
print(el_eliminatories.info())
el_eliminatories.head(5)


# ### Matchs d'Europa League de 2009 à 2019 - Phases de groupe

# In[4]:


# Définition de la page de base à scraper
URL = "https://fr.besoccer.com/competition/resultats/uefa"

# Listes vides pour les données que l'on veut scraper
competition = []
date = []
home_team = []
away_team = []
first_score = []

# Début de la boucle pour recréer l'URL des années 2009 à 2019
for i in range(2010,2020) :
    URL2 = URL+"/"+str(i)+"/groupeall"
    # Début de la boucle pour recréer l'URL des journées 1 à 6 des phases de groupe
    for j in range(1,7) :
        page = requests.get(URL2+'/journee'+str(j))

    # Création de l'objet BeautifulSoup
        soup = BeautifulSoup(page.content, 'html.parser')

    # Scrape competition

        try:
            Comp = soup.findAll('div', attrs={'class':'middle-info ta-c'})
            for element in Comp :
                competition.append(element.text.strip())
        except:
            competition.append(None)

        # Scrape date

        try:
            Dates = soup.findAll('div', attrs={'class':'date'})
            for element in Dates :
                date.append(element.text.strip())
        except:
            date.append(None)

        # Scrape home_team

        try:
            team_h = soup.select(".team_left .name")
            for element in team_h :
                home_team.append(element.text.strip())
        except:
            home_team.append(None)

        # Scrape away_team
        
        try:
            away_h = soup.select(".team_right .name")
            for element in away_h :
                away_team.append(element.text.strip())
        except:
            away_team.append(None)

        # Scrape home_score

        try:
            Scores = soup.findAll('div', attrs={'class':'marker'})
            for element in Scores :
                first_score.append(element.text.strip())
        except:
            first_score.append(None)

        # Journée suivante et fin de la boucle
        j+=1
        
    # Saison suivante et fin de la boucle
    i+=1

# On récupère les éléments qui correspondent uniquement au score grâce à notre fonction clean_score
score=[]
clean_score(first_score)

# Dictionaire contenant les listes avec le noms des colonnes correspondantes

d={'competition' : competition,
   'date' : date,
   'home_team' : home_team,
   'away_team' : away_team,
   'score' : score,}

# DataFrame à partir du dictionnaire

el_gp=pd.DataFrame(d)
print(el_gp.info())
el_gp.head(5)


# ## 2 - Clean des DataFrames obtenus

# ### Gestion des NANs

# In[5]:


# Repérer les valeurs manquantes par colonne

print("Valeurs manquantes el_eliminatories :", "\n", el_eliminatories.isna().sum(axis=0), "\n", "\n","Valeurs manquantes el_gp :", "\n", el_gp.isna().sum(axis = 0))


# ### Mise en forme de la colonne 'Date' (format YYYY-MM-DD puis Datetime)

# In[6]:


# Séparation des années, mois et jours, stockés dans de nouvelles colonnes

    ## el_eliminatories
el_eliminatories['year'] = el_eliminatories['date'].astype(str).str.split(' ', expand=True)[2]
el_eliminatories['month'] = el_eliminatories['date'].astype(str).str.split(' ', expand=True)[1]
el_eliminatories['day'] = el_eliminatories['date'].astype(str).str.split(' ', expand=True)[0]

    ## el_gp
el_gp['year'] = el_gp['date'].astype(str).str.split(' ', expand=True)[2]
el_gp['month'] = el_gp['date'].astype(str).str.split(' ', expand=True)[1]
el_gp['day'] = el_gp['date'].astype(str).str.split(' ', expand=True)[0]

# Remplacement des mois en lettres par des valeurs numériques

    ## el_eliminatories
date_eliminatories = {'FéV':'02','MAR':'03','AVR':'04','MAI':'05'}
el_eliminatories['month'] = el_eliminatories['month'].replace(date_eliminatories)

    ## el_gp
date_gp = {'SEP':'09','OCT':'10','NOV':'11','DéC':'12'}
el_gp['month'] = el_gp['month'].replace(date_gp)

# Création de la nouvelle colonne 'Date' et suppresion des colonnes 'Month' et 'Day' qui ne serviront plus

    ## el_eliminatories
el_eliminatories['date'] = el_eliminatories['year'].str.cat(el_eliminatories['month'], sep='-')
el_eliminatories['date'] = el_eliminatories['date'].str.cat(el_eliminatories['day'], sep='-')
el_eliminatories.drop(['month','day'],axis=1, inplace=True)

    ## el_gp
el_gp['date'] = el_gp['year'].str.cat(el_gp['month'], sep='-')
el_gp['date'] = el_gp['date'].str.cat(el_gp['day'], sep='-')
el_gp.drop(['month','day'],axis=1, inplace=True)

# Format Datetime
el_eliminatories['date'] = pd.to_datetime(el_eliminatories['date'])
el_gp['date'] = pd.to_datetime(el_gp['date'])

# Classement du DataFrame par date croissante et reset de l'index

    ## el_eliminatories
el_eliminatories.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)

    ## el_gp
el_gp.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)


# ### Mise en forme des colonnes 'Home_team' et 'Away_team'

# In[7]:


# On uniformise le nom des équipes par rapport au DataFrame des matchs de premier league

team_to_replace = {'Man. City':'Manchester City',
                   'Man. Utd':'Manchester United',
                    'Newcastle':'Newcastle United'}

    ## el_eliminatories
el_eliminatories['home_team'] = el_eliminatories['home_team'].replace(team_to_replace)
el_eliminatories['away_team'] = el_eliminatories['away_team'].replace(team_to_replace)

    ## el_gp
el_gp['home_team'] = el_gp['home_team'].replace(team_to_replace)
el_gp['away_team'] = el_gp['away_team'].replace(team_to_replace)


# ### Ajout de colonnes

# In[8]:


# Ajout de la colonne 'Season' à partir de la colonne 'Year'

    ## el_eliminatories
season_eliminatories={'2010':'09/10', 
                      '2011':'10/11', 
                      '2012':'11/12', 
                      '2013':'12/13', 
                      '2014':'13/14', 
                      '2015':'14/15', 
                      '2016':'15/16', 
                      '2017':'16/17', 
                      '2018':'17/18', 
                      '2019':'18/19'}

el_eliminatories['season']=el_eliminatories['year'].replace(season_eliminatories)

    ## el_gp
season_gp={'2009':'09/10',
           '2010':'10/11', 
           '2011':'11/12', 
           '2012':'12/13', 
           '2013':'13/14', 
           '2014':'14/15', 
           '2015':'15/16', 
           '2016':'16/17', 
           '2017':'17/18', 
           '2018':'18/19', 
           '2019':'19/20'}

el_gp['season']=el_gp['year'].replace(season_gp)

# Ajout de la colonne 'phase'
el_eliminatories['phase'] = 'Eliminatories'
el_gp['phase'] = 'Group'


# ### Split de la colonne 'Score' en colonnes 'Home_score' et 'Away_score'

# In[9]:


## el_eliminatories
el_eliminatories['home_score'] = el_eliminatories['score'].str.split('-', expand=True)[0].astype(float)
el_eliminatories['away_score'] = el_eliminatories['score'].str.split('-', expand=True)[1].astype(float)
el_eliminatories.drop('score', axis=1, inplace=True)

## el_gp
el_gp['home_score'] = el_gp['score'].str.split('-', expand=True)[0].astype(float)
el_gp['away_score'] = el_gp['score'].str.split('-', expand=True)[1].astype(float)
el_gp.drop('score', axis=1, inplace=True)


# ### Réindexation des colonnes

# In[10]:


## el_eliminatories
el_eliminatories=el_eliminatories.reindex(columns=['competition','date','home_team','away_team','home_score','away_score','year','season','phase'])

## el_gp
el_gp=el_gp.reindex(columns=['competition','date','home_team','away_team','home_score','away_score','year','season','phase'])


# ### Format des colonnes

# In[11]:


## el_eliminatories
el_eliminatories['competition'] = el_eliminatories['competition'].astype(str)
el_eliminatories['home_team'] = el_eliminatories['home_team'].astype(str)
el_eliminatories['away_team'] = el_eliminatories['away_team'].astype(str)
el_eliminatories['phase'] = el_eliminatories['phase'].astype(str)
el_eliminatories['home_score'] = el_eliminatories['home_score'].astype(float)
el_eliminatories['away_score'] = el_eliminatories['away_score'].astype(float)    

## el_gp
el_gp['competition'] = el_gp['competition'].astype(str)
el_gp['home_team'] = el_gp['home_team'].astype(str)
el_gp['away_team'] = el_gp['away_team'].astype(str)
el_gp['phase'] = el_gp['phase'].astype(str)
el_gp['home_score'] = el_gp['home_score'].astype(float)
el_gp['away_score'] = el_gp['away_score'].astype(float)


# In[12]:


print(el_eliminatories.info())
el_eliminatories.head(5)


# In[13]:


print(el_gp.info())
el_gp.head(5)


# ## 3 - Regroupement des DataFrames

# In[14]:


europa_league = pd.concat([el_eliminatories, el_gp], axis=0)

# Classement par date croissante et reset de l'index

europa_league.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)
print(europa_league.shape)
europa_league.head(5)


# ## 4 - Exporter le csv

# In[15]:


europa_league.to_csv(r'clean_csv/europa_league.csv', index=False)

