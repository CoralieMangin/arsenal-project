#!/usr/bin/env python
# coding: utf-8

# In[109]:


import pandas as pd 
import numpy as np 
import seaborn as sns 
import matplotlib.pyplot as plt

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None) 


# In[110]:


# https://www.kaggle.com/vardan95ghazaryan/top-250-football-transfers-from-2000-to-2018/version/1

df = pd.read_csv('top250-00-19.csv')


# In[111]:


df.head()


# In[112]:


df.shape


# In[113]:


df.columns


# ### Check NA

# In[114]:


df.isna().sum()


# ### Replace NaN by Unknown

# In[115]:


df.dtypes


# In[116]:


df['Market_value'] = df['Market_value'].astype('float')


# In[117]:


df['Transfer_fee'] = df['Transfer_fee'].astype('float')


# In[118]:


df.head()


# In[119]:


df.sort_values(by = 'Transfer_fee', ascending = False)


# ### Arsenal transfers (To and From)

# In[120]:


arsenal_transfers = df[(df['Team_from'] == 'Arsenal') | (df['Team_to'] == 'Arsenal')]


# In[121]:


arsenal_transfers


# In[122]:


arsenal_transfers.shape


# In[123]:


arsenal_transfers.sort_values(by = 'Transfer_fee', ascending = False)


# In[124]:


## Team_to 


# In[125]:


to_arsenal = arsenal_transfers[arsenal_transfers['Team_to'] == 'Arsenal']


# In[126]:


to_arsenal.shape


# In[127]:


## Team_from 


# In[128]:


out_arsenal = arsenal_transfers[arsenal_transfers['Team_from'] == 'Arsenal']


# In[129]:


out_arsenal.shape


# ### TO ARSENAL ANALYSIS

# In[130]:


to_arsenal


# In[131]:


## Number of transfers


# In[132]:


num_to_ars = to_arsenal.groupby('Season')[['Name']].count()


# In[133]:


num_to_ars


# In[134]:


sns.relplot(x= 'Season', y = 'Name', data = num_to_ars, kind = 'line')
plt.xticks(fontsize = 7, rotation= 45)
plt.ylabel('Buying count')
plt.show();


# In[135]:


## Positions 


# In[136]:


pos_to_ars = to_arsenal.groupby(['Season', 'Position'])[['Name']].count()


# In[137]:


pos_to_ars


# In[138]:


## Sum of Transfers per season


# In[139]:


sum_buy_to_ars = to_arsenal.groupby('Season')[['Transfer_fee']].sum()


# In[140]:


sum_buy_to_ars


# In[141]:


sns.relplot(x= 'Season', y = 'Transfer_fee', data = sum_buy_to_ars, kind = 'line')
plt.xticks(fontsize = 7, rotation= 45)
plt.ylabel('Buying fee')
plt.show();


# In[142]:


## Percentage change of transfers season after season


# In[143]:


sum_buy_to_ars.pct_change()*100


# In[144]:


## From which league do they get the most transfers? 


# In[145]:


league_buy_from = to_arsenal.groupby(['Season', 'League_from'])[['Name']].count()
league_buy_from


# ### FROM ARSENAL ANALYSIS

# In[146]:


out_arsenal.head()


# In[147]:


## Num of transfers


# In[148]:


num_from_ars = out_arsenal.groupby('Season')[['Name']].count()


# In[149]:


num_from_ars


# In[150]:


sns.relplot(x= 'Season', y = 'Name', data = num_from_ars, kind = 'line')
plt.xticks(fontsize = 7, rotation= 45)
plt.ylabel('Selling count')
plt.show();


# In[151]:


## Positions


# In[152]:


pos_from_ars = out_arsenal.groupby(['Season', 'Position'])[['Name']].count()


# In[153]:


pos_from_ars


# In[154]:


## Sum transfers


# In[155]:


sum_sell_ars = out_arsenal.groupby('Season')[['Transfer_fee']].sum()


# In[156]:


sum_sell_ars


# In[157]:


sns.relplot(x= 'Season', y = 'Transfer_fee', data = sum_sell_ars, kind = 'line')
plt.xticks(fontsize = 7, rotation= 45)
plt.ylabel('Selling fee')
plt.show();


# In[158]:


sum_sell_ars.pct_change()*100


# In[159]:


## Who did they sell their players to the most?


# In[160]:


league_sell_to = out_arsenal.groupby(['Season', 'League_to'])[['Name']].count()


# In[161]:


league_sell_to


# ### COMPARE BUY AND SELL ARSENAL (gather dfs together for each criteria)

# In[162]:


## Num transfers (in vs out)


# In[163]:


arrivals_num = num_to_ars.rename(columns = {'Name': 'arriving arsenal'})
departures_num = num_from_ars.rename(columns = {'Name': 'Leaving arsenal'})


# In[164]:


all_trans_ars = pd.concat([arrivals_num, departures_num], axis=1)


# In[165]:


all_trans_ars


# In[166]:


## Replace NA


# In[167]:


all_trans_ars = all_trans_ars.fillna(0)


# In[168]:


## Change col Leaving Arsenal to int


# In[169]:


all_trans_ars['Leaving arsenal'] = all_trans_ars['Leaving arsenal'].astype(int)


# In[170]:


## Adding diff between in and out column


# In[171]:


all_trans_ars['In_minus_out'] = all_trans_ars['arriving arsenal'] - all_trans_ars['Leaving arsenal']


# In[172]:


all_trans_ars


# In[173]:


all_trans_ars[['arriving arsenal', 'Leaving arsenal']].plot()
plt.xlabel('Season')
plt.ylabel('Transfer count')
plt.show();


# In[174]:


### Same thing for transfer fee


# In[175]:


sum_sell_ars = sum_sell_ars.rename(columns = {'Transfer_fee': 'Sum_gained'})
sum_buy_to_ars = sum_buy_to_ars.rename(columns = {'Transfer_fee': 'Sum_spent'})


# In[176]:


fee_transfers_ars = pd.concat([sum_buy_to_ars,sum_sell_ars], axis = 1)


# In[177]:


fee_transfers_ars = fee_transfers_ars.fillna(0)


# In[178]:


fee_transfers_ars['Spent_minus_gained'] = fee_transfers_ars['Sum_spent'] - fee_transfers_ars['Sum_gained']


# In[179]:


fee_transfers_ars


# In[180]:


fee_transfers_ars[['Sum_spent', 'Sum_gained']].plot()
plt.xlabel('Season')
plt.ylabel('Total transfer fees')
plt.show();


# In[181]:


## Assemble both global in vs out DFs 


# In[182]:


global_ars = pd.concat([all_trans_ars, fee_transfers_ars], axis = 1)


# In[183]:


global_ars


# In[184]:


## It seems that even though they have a more outgoing transfers that incoming ones, 
## they still are losing money on the in vs out per season


# ### Compare to other clubs 

# In[185]:


df.head()


# In[186]:


## SELLING


# In[187]:


# NUMBER OF PLAYERS SOLD BY TEAM


# In[188]:


sell_count = df.groupby('Team_from')[['Name']].count().sort_values(by= 'Name', ascending = False)


# In[189]:


sell_count = sell_count.rename(columns = {'Name': 'Selling'})


# In[190]:


sell_count


# In[191]:


# SUM OF AMOUNT OF TRANSFERS BY TEAM


# In[192]:


sell_fee = df.groupby('Team_from')[['Transfer_fee']].sum()


# In[193]:


sell_fee = sell_fee.sort_values(by = 'Transfer_fee', ascending = False)


# In[194]:


sell_fee = sell_fee.rename(columns = {'Transfer_fee': 'sell_sum'})


# In[195]:


sell_fee


# In[196]:


### BUYING


# In[197]:


buy_count = df.groupby('Team_to')[['Name']].count().sort_values(by = 'Name', ascending = False)


# In[198]:


buy_count = buy_count.rename(columns = {'Name': 'Buying'})


# In[199]:


buy_count


# In[200]:


buy_fee = df.groupby('Team_to')[['Transfer_fee']].sum().sort_values(by= 'Transfer_fee', ascending = False)


# In[201]:


buy_fee = buy_fee.rename(columns = {'Transfer_fee': 'buy_sum'})


# In[202]:


buy_fee


# In[203]:


overall_all = pd.concat([buy_count,sell_count, buy_fee, sell_fee], axis = 1)


# In[208]:


overall_all = overall_all.reset_index().rename(columns = {'index': 'Club'})


# In[210]:


team_to_replace = {'Tottenham' : 'Tottenham Hotspur',
                    'Leicester' : 'Leicester City',   
                    'Stoke' : 'Stoke City', 
                    'West Ham' : 'West Ham United', 
                    'Swansea' : 'Swansea City', 
                    'Hull' : 'Hull City', 
                    'Norwich' : 'Norwich City',
                    'Bournemouth' : 'AFC Bournemouth', 
                    'Brighton' : 'Brighton and Hove Albion',
                    'Huddersfield' : 'Huddersfield Town', 
                    'Cardiff' : 'Cardiff City',
                    'Man City' : 'Manchester City',
                    'Man Utd': 'Manchester United',
                    'FC Barcelona': 'Barcelona',
                    'FC Porto': 'Porto', 
                    'Sevilla FC': 'Sevilla',
                    'FC Schalke 04': 'Schalke 04',
                    'FC Nantes' : 'Nantes'}

overall_all['Club'] = overall_all['Club'].replace(team_to_replace)


# In[211]:


## FILL NAN


# In[212]:


overall_all = overall_all.fillna(0)


# In[213]:


## CHANGE COL TYPES


# In[214]:


overall_all['Selling'] = overall_all['Selling'].astype(int)


# In[215]:


overall_all['Buying'] = overall_all['Buying'].astype(int)


# In[216]:


overall_all


# In[217]:


## Adding diff in vs out


# In[218]:


overall_all['in_minus_out'] = overall_all['Buying'] - overall_all['Selling']


# In[219]:


overall_all['Spent_minus_gained'] = overall_all['buy_sum'] - overall_all['sell_sum']


# In[220]:


overall_all


# In[221]:


overall_all.to_csv('top-250_transfers_2000_2018.csv', sep = ';')


# In[ ]:




