#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Import des packages
from urllib.request import urlopen
from bs4 import BeautifulSoup
import pandas as pd
import requests
import numpy as np


# In[2]:


"""
Ce script permet de webscraper les matchs d'EFL Cup entre 2009 et 2019, en deux DataFrames selon la phase (phase de groupe ou phase éliminatoire).
Ensuite, il les nettoie et les uniformise : 
    - gestion des valeurs manquantes;
    - mise en forme de la date;
    - uniformisation des noms des équipes;
    - etc. 
A la fin, les deux DataFrames sont regroupés et le fichier propre est extrait sous le nom "EFL_cup.csv".
"""


# # Webscraping des données d'EFL Cup

# ## 1 - Récupération des données dans des DataFrames

# ### Matchs d'EFL Cup de 2009 à 2019- Phases éliminatoires

# In[3]:


# Définition de la page de base à scraper
URL = "https://fr.besoccer.com/competition/resultats/capital_one_cup"

# Listes vides pour les données que l'on veut scraper
competition = []
date = []
home_team = []
away_team = []
first_score= []

# Début de la boucle pour recréer l'URL des années 2010 à 2019
for i in range(2010,2020) :
    URL2 = URL+"/"+str(i)+"/groupe0"
    # Début de la boucle pour recréer l'URL des journées 2 à 7 des phases éliminatoires
    for j in range(2,8) :
        page = requests.get(URL2+'/journee'+str(j))

        # Création de l'objet BeautifulSoup
        soup = BeautifulSoup(page.content, 'html.parser')

        # Scrape competition

        try:
            Comp = soup.findAll('div', attrs={'class':'middle-info ta-c'})
            for element in Comp :
                competition.append(element.text.strip())
        except:
            competition.append(None)

        # Scrape date

        try:
            Dates = soup.findAll('div', attrs={'class':'date'})
            for element in Dates :
                date.append(element.text.strip())
        except:
            date.append(None)

        # Scrape home_team

        try:
            team_h = soup.select(".team_left .name")
            for element in team_h :
                home_team.append(element.text.strip())
        except:
            home_team.append(None)

        # Scrape away_team

        try:
            away_h = soup.select(".team_right .name")
            for element in away_h :
                away_team.append(element.text.strip())
        except:
            away_team.append(None)

        # Scrape score

        try:
            Scores = soup.findAll('div', attrs={'class':'marker'})
            for element in Scores :
                first_score.append(element.text.strip())
        except:
            first_score.append(None)

        # Saison suivante et fin de la boucle
        i+=1

# Fonction pour nettoyer la liste des scores de tous les caractères indésirables
score=[]

def clean_score(liste) :
    """
    Cette fonction prend en argument une liste puis effectue un "nettoyage" des valeurs de score en plusieurs étapes. 
    Elle récupère les valeurs entre parenthèses puis ne conserve que les valeurs sans espaces. 
    """
    for indice, element in enumerate(liste):
        if '(' in element :
            new_score = element.split('(')[1]
            liste[indice] = new_score
        else : 
            pass
    for indice, element in enumerate(liste):
        if ')' in element :
            new_score = element.split(')')[0]
            liste[indice] = new_score
        else : 
            pass
    for elements in liste :
        if ' ' not in elements : 
            score.append(elements)

clean_score(first_score)

# Dictionaire contenant les listes avec le noms des colonnes correspondantes

d={'competition' : competition,
   'date' : date,
   'home_team' : home_team,
   'away_team' : away_team,
   'score' : score}

# DataFrame à partir du dictionnaire

efl_eliminatories=pd.DataFrame(d)
print(efl_eliminatories.info())
efl_eliminatories.head(5)


# ### Matchs d'EFL Cup de 2009 à 2019 - Phases de groupe

# In[4]:


# Définition de la page de base à scraper
URL = "https://fr.besoccer.com/competition/resultats/capital_one_cup"

# Listes vides pour les données que l'on veut scraper
competition = []
date = []
home_team = []
away_team = []
first_score= []

# Début de la boucle pour recréer l'URL des années 2010 à 2019 de la première journée (phase de groupe)
for i in range(2010,2020) :
    URL2 = URL+"/"+str(i)+"/groupe0/journee1"
    page = requests.get(URL2)

    # Création de l'objet BeautifulSoup
    soup = BeautifulSoup(page.content, 'html.parser')

    # Scrape competition
    try:
        Comp = soup.findAll('div', attrs={'class':'middle-info ta-c'})
        for element in Comp :
            competition.append(element.text.strip())
    except:
        competition.append(None)

    # Scrape date
    try:
        Dates = soup.findAll('div', attrs={'class':'date'})
        for element in Dates :
            date.append(element.text.strip())
    except:
        date.append(None)

    # Scrape home_team

    try:
        team_h = soup.select(".team_left .name")
        for element in team_h :
            home_team.append(element.text.strip())
    except:
        home_team.append(None)

    # Scrape away_team
    try:
        away_h = soup.select(".team_right .name")
        for element in away_h :
            away_team.append(element.text.strip())
    except:
        away_team.append(None)

    # Scrape score
    try:
        Scores = soup.findAll('div', attrs={'class':'marker'})
        for element in Scores :
            first_score.append(element.text.strip())
    except:
        first_score.append(None)

    # Saison suivante et fin de la boucle
    i+=1

# Fonction pour nettoyer la liste des scores de tous les caractères indésirables
score=[]
clean_score(first_score)

# Dictionaire contenant les listes avec le noms des colonnes correspondantes

d={'competition' : competition,
   'date' : date,
   'home_team' : home_team,
   'away_team' : away_team,
   'score' : score}

# DataFrame à partir du dictionnaire

efl_gp=pd.DataFrame(d)
print(efl_gp.info())
efl_gp.head(5)


# ## 2 - Clean des DataFrames obtenus

# ### Gestion des NANs

# In[5]:


# Repérer les valeurs manquantes par colonne

print("Valeurs manquantes fa_eliminatories :", "\n", efl_eliminatories.isna().sum(axis=0), "\n", "\n","Valeurs manquantes fa_gp :", "\n", efl_gp.isna().sum(axis = 0))


# ### Mise en forme de la colonne 'Date' (format YYYY-MM-DD puis Datetime)

# In[6]:


# Séparation des années, mois et jours, stockés dans de nouvelles colonnes

    ## efl_eliminatories

efl_eliminatories['year'] = efl_eliminatories['date'].astype(str).str.split(' ', expand=True)[2]
efl_eliminatories['month'] = efl_eliminatories['date'].astype(str).str.split(' ', expand=True)[1]
efl_eliminatories['day'] = efl_eliminatories['date'].astype(str).str.split(' ', expand=True)[0]

    ## efl_gp

efl_gp['year'] = efl_gp['date'].astype(str).str.split(' ', expand=True)[2]
efl_gp['month'] = efl_gp['date'].astype(str).str.split(' ', expand=True)[1]
efl_gp['day'] = efl_gp['date'].astype(str).str.split(' ', expand=True)[0]

# Remplacement des mois en lettres par des valeurs numériques
dates_to_replace = {'JAN':'01','FéV':'02','AOû':'08','SEP':'09','OCT':'10','NOV':'11','DéC':'12'}
efl_eliminatories['month'] = efl_eliminatories['month'].replace(dates_to_replace)
efl_gp['month'] = efl_gp['month'].replace(dates_to_replace)

# Création de la nouvelle colonne 'Date' et suppresion des colonnes 'Month' et 'Day' qui ne serviront plus

    ## efl_eliminatories
efl_eliminatories['date'] = efl_eliminatories['year'].str.cat(efl_eliminatories['month'], sep='-')
efl_eliminatories['date'] = efl_eliminatories['date'].str.cat(efl_eliminatories['day'], sep='-')
efl_eliminatories.drop(['month','day'],axis=1, inplace=True)

    ## efl_gp
efl_gp['date'] = efl_gp['year'].str.cat(efl_gp['month'], sep='-')
efl_gp['date'] = efl_gp['date'].str.cat(efl_gp['day'], sep='-')
efl_gp.drop(['month','day'],axis=1, inplace=True)

# Format Datetime
efl_eliminatories['date'] = pd.to_datetime(efl_eliminatories['date'])
efl_gp['date'] = pd.to_datetime(efl_gp['date'])

# Classement du DataFrame par date croissante et reset de l'index
efl_eliminatories.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)
efl_gp.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)


# ### Mise en forme des colonnes 'Home_team' et 'Away_team'

# In[7]:


# On uniformise le nom des équipes par rapport au DataFrame des matchs de premier league

team_to_replace = {'Man. City':'Manchester City',
                   'Man. Utd':'Manchester United',
                    'Newcastle':'Newcastle United',
                    'West Ham':'West Ham United',
                    'Leicester':'Leicester City',
                    'Wolves':'Wolverhampton Wanderers'}

    ## efl_eliminatories
    
efl_eliminatories['home_team'] = efl_eliminatories['home_team'].replace(team_to_replace)
efl_eliminatories['away_team'] = efl_eliminatories['away_team'].replace(team_to_replace)

    ## efl_gp
    
efl_gp['home_team'] = efl_gp['home_team'].replace(team_to_replace)
efl_gp['away_team'] = efl_gp['away_team'].replace(team_to_replace)


# ### Ajout de colonnes

# In[8]:


# Ajout de la colonne 'Season'

    ## efl_eliminatories

season09 = (efl_eliminatories['date'] > '2009-07-01') & (efl_eliminatories['date'] < '2010-04-01')
efl_eliminatories.loc[season09, 'season']='09/10'

season10 = (efl_eliminatories['date'] > '2010-07-01') & (efl_eliminatories['date'] < '2011-04-01')
efl_eliminatories.loc[season10, 'season']='10/11'

season11 = (efl_eliminatories['date'] > '2011-07-01') & (efl_eliminatories['date'] < '2012-04-01')
efl_eliminatories.loc[season11, 'season']='11/12'

season12 = (efl_eliminatories['date'] > '2012-07-01') & (efl_eliminatories['date'] < '2013-04-01')
efl_eliminatories.loc[season12, 'season']='12/13'

season13 = (efl_eliminatories['date'] > '2013-07-01') & (efl_eliminatories['date'] < '2014-04-01')
efl_eliminatories.loc[season13, 'season']='13/14'

season14 = (efl_eliminatories['date'] > '2014-07-01') & (efl_eliminatories['date'] < '2015-04-01')
efl_eliminatories.loc[season14, 'season']='14/15'

season15 = (efl_eliminatories['date'] > '2015-07-01') & (efl_eliminatories['date'] < '2016-04-01')
efl_eliminatories.loc[season15, 'season']='15/16'

season16 = (efl_eliminatories['date'] > '2016-07-01') & (efl_eliminatories['date'] < '2017-04-01')
efl_eliminatories.loc[season16, 'season']='16/17'

season17 = (efl_eliminatories['date'] > '2017-07-01') & (efl_eliminatories['date'] < '2018-04-01')
efl_eliminatories.loc[season17, 'season']='17/18'

season18 = (efl_eliminatories['date'] > '2018-07-01') & (efl_eliminatories['date'] < '2019-04-01')
efl_eliminatories.loc[season18, 'season']='18/19'

    ## efl_gp

season09 = (efl_gp['date'] > '2009-07-01') & (efl_gp['date'] < '2010-04-01')
efl_gp.loc[season09, 'season']='09/10'

season10 = (efl_gp['date'] > '2010-07-01') & (efl_gp['date'] < '2011-04-01')
efl_gp.loc[season10, 'season']='10/11'

season11 = (efl_gp['date'] > '2011-07-01') & (efl_gp['date'] < '2012-04-01')
efl_gp.loc[season11, 'season']='11/12'

season12 = (efl_gp['date'] > '2012-07-01') & (efl_gp['date'] < '2013-04-01')
efl_gp.loc[season12, 'season']='12/13'

season13 = (efl_gp['date'] > '2013-07-01') & (efl_gp['date'] < '2014-04-01')
efl_gp.loc[season13, 'season']='13/14'

season14 = (efl_gp['date'] > '2014-07-01') & (efl_gp['date'] < '2015-04-01')
efl_gp.loc[season14, 'season']='14/15'

season15 = (efl_gp['date'] > '2015-07-01') & (efl_gp['date'] < '2016-04-01')
efl_gp.loc[season15, 'season']='15/16'

season16 = (efl_gp['date'] > '2016-07-01') & (efl_gp['date'] < '2017-04-01')
efl_gp.loc[season16, 'season']='16/17'

season17 = (efl_gp['date'] > '2017-07-01') & (efl_gp['date'] < '2018-04-01')
efl_gp.loc[season17, 'season']='17/18'

season18 = (efl_gp['date'] > '2018-07-01') & (efl_gp['date'] < '2019-04-01')
efl_gp.loc[season18, 'season']='18/19'

# Ajout de la colonne 'phase'
efl_eliminatories['phase'] = 'Eliminatories'
efl_gp['phase'] = 'Group'


# ### Split de la colonne 'Score' en colonnes 'Home_score' et 'Away_score'

# In[9]:


# Split du score en deux colonnes
efl_eliminatories['home_score'] = efl_eliminatories['score'].str.split('-', expand=True)[0].astype(float)
efl_eliminatories['away_score'] = efl_eliminatories['score'].str.split('-', expand=True)[1].astype(float)
efl_eliminatories.drop('score', axis=1, inplace=True)

# Split du score en deux colonnes
efl_gp['home_score'] = efl_gp['score'].str.split('-', expand=True)[0].astype(float)
efl_gp['away_score'] = efl_gp['score'].str.split('-', expand=True)[1].astype(float)
efl_gp.drop('score', axis=1, inplace=True)


# ### Réindexation des colonnes

# In[10]:


efl_eliminatories = efl_eliminatories.reindex(columns=['competition','date','home_team','away_team','home_score','away_score','year','season','phase'])
efl_gp = efl_gp.reindex(columns=['competition','date','home_team','away_team','home_score','away_score','year','season','phase'])


# ### Format des colonnes

# In[11]:


## efl_eliminatories

efl_eliminatories['competition'] = efl_eliminatories['competition'].astype(str)
efl_eliminatories['home_team'] = efl_eliminatories['home_team'].astype(str)
efl_eliminatories['away_team'] = efl_eliminatories['away_team'].astype(str)
efl_eliminatories['phase'] = efl_eliminatories['phase'].astype(str)
efl_eliminatories['home_score'] = efl_eliminatories['home_score'].astype(float)
efl_eliminatories['away_score'] = efl_eliminatories['away_score'].astype(float)  

## efl_gp

efl_gp['competition'] = efl_gp['competition'].astype(str)
efl_gp['home_team'] = efl_gp['home_team'].astype(str)
efl_gp['away_team'] = efl_gp['away_team'].astype(str)
efl_gp['phase'] = efl_gp['phase'].astype(str)
efl_gp['home_score'] = efl_gp['home_score'].astype(float)
efl_gp['away_score'] = efl_gp['away_score'].astype(float) 


# In[12]:


print(efl_eliminatories.info())
efl_eliminatories.head(5)


# In[13]:


print(efl_gp.info())
efl_gp.head(5)


# ## 3 - Regroupement des DataFrames

# In[14]:


efl_cup = pd.concat([efl_eliminatories, efl_gp], axis=0)

# Classement par date croissante et reset de l'index

efl_cup.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)
print(efl_cup.shape)
efl_cup.tail(5)


# In[15]:


efl_cup.info()


# ## 4 - Exporter le csv

# In[16]:


efl_cup.to_csv(r'clean_csv/EFL_cup.csv', index=False)

