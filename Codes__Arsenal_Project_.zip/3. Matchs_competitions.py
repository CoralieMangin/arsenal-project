#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Origine des csv : webscraping
# Voir les 4 scripts numérotés en '2.' ("2. Champions_League.py", etc.)

"""
Ce script rassemble en un seul DataFrame les datasets des 4 compétitions récupérés précédement comme indiqué ci-dessus.
Ensuite il l'uniformise par rapport au dataset initial (ajout de colonnes).
A la fin, le fichier est extrait sous le nom "matchs_competitions.csv".
"""


# # Concaténation des DataFrames des différentes compétitions

# In[2]:


# Import des modules
import numpy as np
import pandas as pd

# Import des DataFrames des matchs des compétitions nationales et européennes
cl = pd.read_csv(r'clean_csv/champions_league.csv')
el = pd.read_csv(r'clean_csv/europa_league.csv')
fa = pd.read_csv(r'clean_csv/FA_cup.csv')
efl = pd.read_csv(r'clean_csv/EFL_cup.csv')

# Concaténation en un seul DataFrame
df = pd.concat([cl, el, fa, efl], axis=0, ignore_index=True)

# Classement par date croissante et reset de l'index
df.sort_values(by='date', ascending=True, inplace=True, ignore_index=True)

# Affichage des caractéristiques et des premières lignes du DataFrame
print(df.info())
df.head(5)


# ## Ajout de colonnes

# In[3]:


# Définition d'une fonction pour récupérer le nom de l'équipe gagante selon la différence de score et stockage des valeurs dans une nouvelle colonne 'Win'

def winning_team(c): 
    """
    Cette fonction prend un seul paramètre (un DataFrame) puis retourne le nom de l'équipe gagnante selon le nombre de buts marqués par chacune des deux équipes.
    Elle prend en considération la possibilité de match nul et retourne alors 'None'.
    """
    if c['home_score'] > c['away_score']:
        return c['home_team']
    elif c['home_score'] < c['away_score']:
        return c['away_team']
    elif c['home_score'] == c['away_score']:
        return 'None'

df['Win'] = df.apply(winning_team, axis= 1)

# Définition d'une fonction pour récupérer le nom de l'équipe perdante selon la différence de score et stockage des valeurs dans une nouvelle colonne 'Loss'

def losing_team(c):
    """
    Cette fonction prend un seul paramètre (un DataFrame) puis retourne le nom de l'équipe perdante selon le nombre de buts marqués par chacune des deux équipes.
    Elle prend en considération la possibilité de match nul et retourne alors 'None'.
    """
    if c['home_score'] > c['away_score']:
        return c['away_team']
    elif c['home_score'] < c['away_score']:
        return c['home_team']
    elif c['home_score'] == c['away_score']:
        return 'None'

df['Loss'] = df.apply(losing_team, axis= 1)

# Définition de 2 fonctions pour récupérer le nom des équipes à domicile et à l'extérieur lors d'égalités

def draw_home(c):
    """
    Cette fonction prend un seul paramètre (un DataFrame) puis retourne le nom de l'équipe à domicile lors d'un match nul.
    """
    if c['home_score'] == c['away_score']:
        return c['home_team']
    else :
        'N/A'

def draw_away(c):
    """
    Cette fonction prend un seul paramètre (un DataFrame) puis retourne le nom de l'équipe à l'extérieur lors d'un match nul.
    """
    if c['home_score'] == c['away_score']:
        return c['away_team']
    else :
        'N/A'

## Stockage des valeurs dans 2 nouvelles colonnes 'draw_home' et 'draw_away'

df['draw_home'] = df.apply(draw_home, axis= 1)
df['draw_away'] = df.apply(draw_away, axis= 1)

# Définition d'une fonction pour afficher le résultat des matchs pour l'équipe Arsenal

def arsenal_results(c):
    """
    Cette fonction prend un seul paramètre (un DataFrame) puis compare le nombre de buts marqués pour chacune des deux équipes par match, 
    selon qu'Arsenal joue à domicile ou à l'extérieur. 
    Elle retourne le résultat du match du point de vue de l'équipe Arsenal : 'W' en cas de victoire, 'L' en cas de défaite, 'D' en cas d'égalité.
    """
    if (c['home_team'] == 'Arsenal') & (c['home_score'] > c['away_score']):
        return 'W'
    elif (c['home_team'] == 'Arsenal') & (c['home_score'] < c['away_score']):
        return 'L'
    elif (c['home_team'] == 'Arsenal') & (c['home_score'] == c['away_score']):
        return 'D'
    elif (c['away_team'] == 'Arsenal') & (c['home_score'] > c['away_score']):
        return 'L'
    elif (c['away_team'] == 'Arsenal') & (c['home_score'] < c['away_score']):
        return 'W'
    elif (c['away_team'] == 'Arsenal') & (c['home_score'] == c['away_score']):
        return 'D'
    else:
        'N/A'
        
# Stockage des valeurs dans une nouvelle colonne 'arsenal_results'
df['arsenal_results'] = df.apply(arsenal_results, axis=1).astype(str)


# ## Remplacer les points par des virgules

# In[4]:


# Méthode 'replace' sur les '.' pour avoir des ',', appliqué à toutes les colonnes de df

df = df.astype(str).apply(lambda x: x.str.replace('.',','))
df.head(5)


# ## Exporter le csv

# In[5]:


# Matchs de compétitions nationales et européennes
df.to_csv(r'clean_csv/matchs_competitions.csv', index=False)

